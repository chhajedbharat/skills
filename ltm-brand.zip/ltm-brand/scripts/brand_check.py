#!/usr/bin/env python3
"""LTM brand compliance check for a .pptx, .docx or .xlsx file.

Reads the file's XML (no network, nothing is modified) and reports:
  - colours that are not in the LTM palette (with where they occur)
  - fonts other than Arial / ES Klarheit Grotesk (Calibri usually means a font fell back)
  - slides: bold display headlines, type under 12pt, text-heavy slides, coral overuse,
    small coral text on light grounds, LTM logo on interior slides / missing from cover or closer
Usage:
  python brand_check.py <file> [--json]
For a live PowerPoint deck, first get a workspace copy of the current bytes (the model read with
render=true returns its path), then run this on that copy.
"""
import sys, re, json, zipfile, math
from collections import defaultdict, Counter

PALETTE = {
    # core screen palette
    "FF5E4F": "LTM Coral", "E2463A": "Coral Text (coral words on light grounds)", "1A1A1A": "Ink", "E9E9E9": "Cloud Grey", "FFFFFF": "White",
    "000000": "Black", "3D3D3D": "Graphite", "559BB5": "Steel Blue", "004B88": "L&T Blue",
    # supporting tints / neutrals (annual report & cards)
    "FEF2ED": "Coral Wash", "FEF2EE": "Coral Wash", "FEEFE9": "Coral Wash", "FCD3C6": "Coral Tint",
    "57585B": "Slate (secondary text)", "ACA9A9": "Mist (captions on dark)", "CCCBCA": "Prior-period Grey",
    "D1D2D4": "Rule Grey", "DDDEE0": "Light Grey", "EAEBEC": "Subtotal Grey", "F0F0F0": "Card Grey",
    "ECECEC": "Card Grey", "F6F6F6": "Card Grey", "F5F5F5": "Card Grey", "F4F4F4": "Card Grey",
    "F2F2F2": "Card Grey", "EEEEEE": "Card Grey", "F7F7F7": "Card Grey", "E2463A": "Coral Text",
    # contextual sustainability accents (ESG sections only)
    "35754E": "ESG Green", "9AAF9C": "ESG Sage",
}
PRINT_VARIANTS = {"F15F53", "F15F56", "F1665B", "F2665B", "191919", "151515", "231F20", "569BB5"}
FONTS_OK = ("arial", "es klarheit grotesk", "klarheit")

def lum(h):
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]

def contrast(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la + 0.05) / (lb + 0.05)

def norm(h):
    h = h.upper().lstrip("#")
    return h[2:] if len(h) == 8 else h

def check_colours(xml, where, issues, counts):
    for m in re.finditer(r'(?:srgbClr val|w:color w:val|w:fill|rgb)="([0-9A-Fa-f]{6,8})"', xml):
        h = norm(m.group(1))
        if h in ("AUTO",):
            continue
        counts[h] += 1
        if h not in PALETTE:
            issues["off_palette"][h].add(where)

def check_fonts(xml, where, issues):
    for m in re.finditer(r'(?:typeface|w:ascii|w:hAnsi|<name val)="([^"]+)"', xml):
        f = m.group(1)
        if f.startswith("+") or f == "":
            continue
        if not any(ok in f.lower() for ok in FONTS_OK):
            issues["fonts"][f].add(where)

def pptx(z, issues, notes):
    slides = sorted([n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)],
                    key=lambda n: int(re.findall(r"\d+", n)[-1]))
    pres = z.read("ppt/presentation.xml").decode("utf8", "ignore")
    m = re.search(r'<p:sldSz cx="(\d+)" cy="(\d+)"', pres)
    W, H = (int(m.group(1)), int(m.group(2))) if m else (12192000, 6858000)
    if (W, H) != (12192000, 6858000):
        notes.append(f"Slide size is {W}x{H} EMU; LTM decks are 16:9 (12192000x6858000).")
    counts = Counter()
    for i, name in enumerate(slides, 1):
        xml = z.read(name).decode("utf8", "ignore")
        where = f"slide {i}"
        check_colours(xml, where, issues, counts)
        check_fonts(xml, where, issues)
        bgm = re.search(r"<p:bg>.*?srgbClr val=\"([0-9A-Fa-f]{6})\"", xml, re.S)
        ground = norm(bgm.group(1)) if bgm else "FFFFFF"
        # a picture ground (image background or full-bleed picture) cannot be contrast-checked from XML
        bg_block = re.search(r"<p:bg>(.*?)</p:bg>", xml, re.S)
        image_ground = bool(bg_block and "<a:blip" in bg_block.group(1)) or any(
            int(cx) >= 0.9 * W and int(cy) >= 0.9 * H
            for cx, cy in re.findall(r'<p:pic>.*?<a:ext cx="(\d+)" cy="(\d+)"', xml, re.S))
        if image_ground:
            notes.append(f"{where}: picture ground - check text contrast on the render")
        words = 0; coral_area = 0; on_art = 0; ghost = 0
        pic_rects = []
        for pic in re.findall(r"<p:pic>.*?</p:pic>", xml, re.S):
            mo = re.search(r'<a:off x="(-?\d+)" y="(-?\d+)"/>\s*<a:ext cx="(\d+)" cy="(\d+)"', pic)
            if mo:
                px, py, pcx, pcy = map(int, mo.groups())
                if pcx < 0.9 * W or pcy < 0.9 * H:          # cards / tiles, not full-slide grounds
                    pic_rects.append((px, py, px + pcx, py + pcy))
        for sp in re.findall(r"<p:sp>.*?</p:sp>", xml, re.S):
            sppr = re.search(r"<p:spPr[^>]*>(.*?)</p:spPr>", sp, re.S)
            sppr = re.sub(r"<a:ln.*?</a:ln>", "", sppr.group(1), flags=re.S) if sppr else ""
            fill = re.search(r"<a:solidFill><a:srgbClr val=\"([0-9A-Fa-f]{6})\"\s*(/>|>(.*?)</a:srgbClr>)", sppr, re.S)
            ext = re.search(r'<a:ext cx="(\d+)" cy="(\d+)"', sp)
            shape_fill = norm(fill.group(1)) if fill else None
            if fill and fill.group(3):
                am = re.search(r'<a:alpha val="(\d+)"', fill.group(3))
                if am and int(am.group(1)) < 50000:      # transparent text-box fill = no fill
                    shape_fill = None
            if shape_fill == "FF5E4F" and ext:
                coral_area += int(ext.group(1)) * int(ext.group(2))
            local_ground = shape_fill or ground
            so = re.search(r'<a:off x="(-?\d+)" y="(-?\d+)"/>\s*<a:ext cx="(\d+)" cy="(\d+)"', sp)
            over_art = False
            if so and not shape_fill:
                sx, sy, scx, scy = map(int, so.groups()); cx_, cy_ = sx + scx / 2, sy + scy / 2
                over_art = any(a <= cx_ <= c and b <= cy_ <= d for a, b, c, d in pic_rects)
            for r in re.findall(r"<a:r>.*?</a:r>", sp, re.S):
                t = "".join(re.findall(r"<a:t>([^<]*)</a:t>", r))
                words += len(t.split())
                rpr = re.search(r"<a:rPr([^>]*)", r)
                attrs = rpr.group(1) if rpr else ""
                sz = re.search(r'sz="(\d+)"', attrs)
                size = int(sz.group(1)) / 100 if sz else None
                col = re.search(r'srgbClr val="([0-9A-Fa-f]{6})"', r)
                colour = norm(col.group(1)) if col else None
                if size and size >= 28 and re.search(r'\bb="1"', attrs) and t.strip():
                    issues["bold_headline"].add(f"{where}: \"{t.strip()[:40]}\" ({size:g}pt bold)")
                if size and size < 12 and t.strip():
                    issues["small_type"].add(f"{where}: \"{t.strip()[:30]}\" ({size:g}pt)")
                if colour and t.strip() and over_art:
                    on_art += 1
                elif colour == "3D3D3D" and local_ground == "1A1A1A" and size and size >= 40:
                    ghost += 1
                elif colour and t.strip() and not (image_ground and not shape_fill):
                    cr = contrast(colour, local_ground)
                    bold = bool(re.search(r'\bb="1"', attrs))
                    large = size and (size >= 18 or (bold and size >= 14))
                    if cr < (3.0 if large else 4.5):
                        issues["contrast"].add(f"{where}: \"{t.strip()[:30]}\" #{colour} on #{local_ground} = {cr:.2f}:1"
                                               + (" (large text)" if large else ""))
        if on_art:
            notes.append(f"{where}: {on_art} text run(s) sit on card/tile artwork - check their contrast on the render")
        if ghost:
            notes.append(f"{where}: {ghost} decorative ghost line(s) in Graphite on Ink (brand-intentional)")
        if words > 110:
            issues["dense"].add(f"{where}: {words} words")
        if coral_area / (W * H) > 0.40 and ground != "FF5E4F":
            issues["coral_overuse"].add(f"{where}: coral shapes cover {coral_area / (W * H):.0%} of the slide")
        tags = re.findall(r"<p:pic>.*?<p:cNvPr ([^>]*)>", xml, re.S)
        has_logo = any(re.search(r'(?:name|descr)="[^"]*ltm[\s_-]*logo', t, re.I) for t in tags)
        if has_logo and 1 < i < len(slides):
            issues["logo"].add(f"{where}: LTM logo on an interior slide (keep it to the cover and closing slide)")
        if not has_logo and i in (1, len(slides)) and len(slides) > 1:
            issues["logo"].add(f"{where}: no picture named/alt-texted 'LTM logo' found on the {'cover' if i == 1 else 'closing slide'}")
    return counts, len(slides)

def generic(z, parts, issues):
    counts = Counter()
    for name in parts:
        xml = z.read(name).decode("utf8", "ignore")
        check_colours(xml, name, issues, counts)
        check_fonts(xml, name, issues)
    return counts

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    path = sys.argv[1]; as_json = "--json" in sys.argv
    issues = {k: defaultdict(set) for k in ("off_palette", "fonts")}
    for k in ("bold_headline", "small_type", "dense", "coral_overuse", "contrast", "logo"):
        issues[k] = set()
    notes = []
    z = zipfile.ZipFile(path)
    names = z.namelist()
    if any(n.startswith("ppt/") for n in names):
        kind = "pptx"; counts, n = pptx(z, issues, notes); notes.insert(0, f"{n} slides checked")
    elif any(n.startswith("word/") for n in names):
        kind = "docx"; parts = [n for n in names if re.match(r"word/(document|header\d*|footer\d*)\.xml$", n)]
        counts = generic(z, parts, issues)
    elif any(n.startswith("xl/") for n in names):
        kind = "xlsx"; parts = [n for n in names if re.match(r"xl/(styles|worksheets/sheet\d+)\.xml$", n)]
        counts = generic(z, parts, issues)
    else:
        print("Not an Office file"); sys.exit(1)
    variants = sorted(h for h in issues["off_palette"] if h in PRINT_VARIANTS)
    off = {h: sorted(w) for h, w in issues["off_palette"].items() if h not in PRINT_VARIANTS}
    result = {
        "file": path, "kind": kind, "notes": notes,
        "palette_used": {h: (PALETTE.get(h, "off-palette"), c) for h, c in counts.most_common()},
        "off_palette_colours": off,
        "print_variant_colours": variants,
        "non_brand_fonts": {f: sorted(w) for f, w in issues["fonts"].items()},
        "bold_display_headlines": sorted(issues["bold_headline"]),
        "type_under_12pt": sorted(issues["small_type"]),
        "low_contrast_text": sorted(issues["contrast"]),
        "text_heavy_slides": sorted(issues["dense"]),
        "coral_overuse": sorted(issues["coral_overuse"]),
        "logo_placement": sorted(issues["logo"]),
    }
    flags = sum(len(v) for k, v in result.items() if k not in ("file", "kind", "notes", "palette_used", "print_variant_colours"))
    result["verdict"] = "on-brand" if flags == 0 else f"{flags} item(s) to review"
    if as_json:
        print(json.dumps(result, indent=2)); return
    print(f"LTM brand check - {path} ({kind}) - {result['verdict']}")
    for n in notes: print("  note:", n)
    for key, label in [("off_palette_colours", "Off-palette colours"), ("non_brand_fonts", "Non-brand fonts"),
                       ("bold_display_headlines", "Bold display headlines"), ("type_under_12pt", "Type under 12pt"),
                       ("low_contrast_text", "Low-contrast text"), ("text_heavy_slides", "Text-heavy slides"),
                       ("coral_overuse", "Coral overuse"), ("logo_placement", "Logo placement")]:
        v = result[key]
        if v:
            print(f"- {label}:")
            items = v.items() if isinstance(v, dict) else [(x, None) for x in v]
            for a, b in list(items)[:25]:
                print(f"    {a}" + (f"  ({', '.join(b[:6])})" if b else ""))
    if variants:
        print(f"- Print-variant colours (fine in print, use screen values on slides): {', '.join(variants)}")

if __name__ == "__main__":
    main()
