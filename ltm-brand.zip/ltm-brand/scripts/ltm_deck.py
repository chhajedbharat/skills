#!/usr/bin/env python3
"""LTM deck builder: turns a slide plan into ready-to-send live PowerPoint patch batches.

Every layout reproduces a slide archetype from LTM's corporate deck (Feb 2026) and Integrated
Annual Report FY26, adapted to the live PowerPoint engine (tested Nov 2026):
  * pictures are authored before every text/shape op of their slide (the engine defers a picture
    written after any shape to the top of the z-order, where it hides text);
  * Arial (the Office stand-in for ES Klarheit Grotesk), colour stated at creation, left alignment
    stated, type >= 12pt, short labels pre-wrapped so they never auto-wrap;
  * coral words on light grounds use Coral Text E2463A (>= 3:1); true Coral FF5E4F is for fills,
    graphics and type on dark grounds; small text on coral is ink;
  * large rounded cards are PNG art (live roundRect corners cannot be set), data visuals are shapes.

  python ltm_deck.py --plan working/plan.json --out working/ltm-deck
  python ltm_deck.py --layouts            # list layouts and their fields

Writes to --out: manifest.json (call order + fit warnings), NN-*.json patch arrays (send each as
patches_file, in manifest order) and img/ (logos, waves, card art referenced by the patches).
"""
import argparse, json, math, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(os.path.dirname(HERE), "assets")
sys.path.insert(0, HERE)
from make_card import card as make_card_png  # noqa: E402

W, H = 12192000, 6858000            # 16:9 canvas, EMU
M = 457200                          # 0.5in safe margin
CW = W - 2 * M
G = 228600                          # gutter
PT = 12700
FONT = "Arial"
EYEBROW_Y, TITLE_Y = M, 731520      # every interior header hangs from the same x/y
BOTTOM = H - M - 320040             # content stops above the page-number / source line
NBSP = "\u00a0"
WS = "/mnt/workspace"
C = dict(coral="FF5E4F", coral_text="E2463A", ink="1A1A1A", cloud="E9E9E9", white="FFFFFF",
         black="000000", graphite="3D3D3D", steel="559BB5", ltblue="004B88", slate="57585B",
         mist="ACA9A9", wash="FEF2ED", prior="CCCBCA", rule="D1D2D4")
LOGO_RATIO = 3.8                    # LTM wordmark width / height
LT_RATIO = 5.2556                   # "A Larsen & Toubro Group Company" lockup width / height

LAYOUTS = {
    "cover":           "title, subtitle?, meta? (date / presenter) - dark particle-wave cover, L&T endorsement + LTM logo",
    "agenda":          "title?, items[] (<= 6 short strings)",
    "section":         "number? ('02'), title, subtitle? - ink divider with particle wave",
    "statement":       "eyebrow?, lead (coral words), rest (ink words), support? - light statement, particle corner",
    "context_cards":   "eyebrow?, title, intro?, cards[] (2-5 short statements), bar? (so-what line in a coral bar)",
    "pillars":         "eyebrow?, title, intro?, pillars[] (3 x {title, text}) - coral / ink / white numbered cards",
    "shifts":          "eyebrow?, lead (ink), emphasis (coral), shifts[] (<= 3 x [from, to])",
    "stats":           "eyebrow?, title, lead?, emphasis?, tail?, stats[] (2-4 x {value, label}), endorsement? (true = L&T tile)",
    "cards":           "eyebrow?, title, intro?, cards[] (3-4 x {title, text}), ground? (white|cloud)",
    "offerings":       "eyebrow?, title, offerings[] (3 x {name, text}), caption?",
    "bar_compare":     "eyebrow?, title, unit?, current_label, prior_label?, rows[] ({label, current, prior?}), takeaway?, source?",
    "table":           "eyebrow?, title, header[], rows[][], takeaway?, source?",
    "case_study":      "eyebrow? (industry), title, context, challenge, approach, impact[] (bullets), image? (workspace path), image_alt?",
    "quote":           "quote, name, role?",
    "timeline":        "eyebrow?, title, steps[] (3-6 x {when, what})",
    "logo_wall":       "eyebrow?, title, partners[] ({name, logo? (workspace path), note?})",
    "recognitions":    "eyebrow?, title, items[] (<= 9 strings)",
    "manifesto":       "ghost[]? (2-4 words), lead? ('It's time to'), emphasis? ('Outcreate.')",
    "photo_statement": "eyebrow?, title?, statement, support?, image (workspace path), image_alt?",
    "closing":         "lead? ('It's time to'), emphasis? ('Outcreate'), contact?",
}

# ------------------------------------------------------------------ text measurement
def _greedy(words, maxc):
    out, cur = [], ""
    for w in words:
        if not cur: cur = w
        elif len(cur) + 1 + len(w) <= maxc: cur += " " + w
        else: out.append(cur); cur = w
    if cur: out.append(cur)
    return out

def wrap(text, size, cx, em=0.61, balance=True):
    """Wrap with a conservative Arial width (0.61 em/char, the platform QA's own estimate), then
    balance the rag: the narrowest measure that keeps the same line count (no orphan words)."""
    maxc = max(1, int((cx - 182880) / (size * PT * em)))
    out = []
    for para in str(text).split("\n"):
        words = para.split()
        if not words:
            out.append(""); continue
        lines = _greedy(words, maxc)
        if balance and len(lines) > 1:
            for c in range(max(len(w) for w in words), maxc + 1):
                trial = _greedy(words, c)
                if len(trial) == len(lines):
                    lines = trial; break
        out += lines
    return out

def bh(n, size, lead=1.2):
    return int(n * size * PT * lead + 91440)

def rel(p):
    ap = os.path.abspath(p)
    return os.path.relpath(ap, WS) if ap.startswith(WS + os.sep) else p

# ------------------------------------------------------------------ op helpers
def tb(s, x, y, cx, cy, text, size, color, bold=False, align="left", ls=None, name=None):
    op = {"op": "add_text_box", "slide": s, "x": int(x), "y": int(y), "cx": int(cx), "cy": int(cy),
          "text": text, "sizePt": size, "color": color, "fontFamily": FONT, "bold": bold, "align": align}
    if ls: op["letterSpacingPt"] = ls
    if name: op["name"] = name
    return op

def tbp(s, x, y, cx, cy, paras, align="left", name=None):
    op = {"op": "add_text_box", "slide": s, "x": int(x), "y": int(y), "cx": int(cx), "cy": int(cy),
          "paragraphs": paras, "fontFamily": FONT, "align": align}
    if name: op["name"] = name
    return op

def shape(s, preset, x, y, cx, cy, fill, text=None, size=None, color=None, bold=False, align="center", name=None):
    op = {"op": "add_shape", "slide": s, "preset": preset, "x": int(x), "y": int(y), "cx": int(cx), "cy": int(cy), "fill": fill}
    if text is not None:
        op.update(text=text, sizePt=size, color=color, fontFamily=FONT, bold=bold, align=align)
    if name: op["name"] = name
    return op

def image(s, path, x, y, cx, cy, alt="", name=None, fit=None):
    op = {"op": "add_image", "slide": s, "path": rel(path), "x": int(x), "y": int(y), "cx": int(cx), "cy": int(cy)}
    if alt: op["altText"] = alt          # live refuses an empty altText; decorative art carries none
    if fit: op["fit"] = fit
    if name: op["name"] = name
    return op

def contain(path, x, y, cx, cy):
    try:
        from PIL import Image
        iw, ih = Image.open(path).size
    except Exception:
        return x, y, cx, cy
    r = min(cx / iw, cy / ih); w, h = int(iw * r), int(ih * r)
    return x + (cx - w) // 2, y + (cy - h) // 2, w, h

class Deck:
    def __init__(self, out):
        self.out = out; self.img = os.path.join(out, "img"); os.makedirs(self.img, exist_ok=True)
        self.warn = []; self.ground = {}; self.image_ground = {}

    def asset(self, relpath):
        src = os.path.join(ASSETS, relpath); dst = os.path.join(self.img, os.path.basename(relpath))
        if not os.path.exists(dst): shutil.copyfile(src, dst)
        return dst

    def card(self, key, cx, cy, style="frost", fill="FFFFFF", ground="cloud"):
        from PIL import Image  # noqa: F401
        p = os.path.join(self.img, f"{key}.png")
        make_card_png(cx, cy, style, fill, ground).save(p, optimize=True)
        return p

    def lines(self, s, label, text, size, cx, max_lines, em=0.61):
        ls = wrap(text, size, cx, em)
        if len(ls) > max_lines:
            self.warn.append(f"slide {s + 1}: {label} needs {len(ls)} lines at {size}pt (max {max_lines}) - shorten it")
            ls = ls[:max_lines]
        return ls

def padded(ls, n):
    return "\n".join(ls + [NBSP] * (n - len(ls)))

def text_lines(d, s, label, text, size, x, y, cx, color, max_lines, bold=False, align="left", pad_to=None, name=None):
    """Pre-wrapped text box (explicit line breaks, so neither PowerPoint nor the QA re-wraps it)."""
    ls = d.lines(s, label, text, size, cx, max_lines, 0.66 if bold else 0.61)
    n = max(len(ls), pad_to or 0)
    return tb(s, x, y, cx, bh(n, size), padded(ls, n), size, color, bold, align, name=name), bh(n, size)

def display(d, s, segs, size, x, y, cx, max_lines, align="left", name=None):
    """Display type: one plain multi-line text box per colour segment, stacked without overlap.
    (Plain '\n' text is the proven live path; per-paragraph colour boxes are avoided.)"""
    ops, used = [], 0
    for i, (text, color) in enumerate(segs):
        ls = wrap(text, size, cx)
        if used + len(ls) > max_lines:
            d.warn.append(f"slide {s + 1}: display text needs {used + len(ls)} lines at {size}pt (max {max_lines}) - shorten it")
            ls = ls[:max(0, max_lines - used)]
        if not ls:
            continue
        h = bh(len(ls), size, 1.18)
        ops.append(tb(s, x, y, cx, h, "\n".join(ls), size, color, align=align,
                      name=(f"{name} {i + 1}" if name and len(segs) > 1 else name)))
        y += h; used += len(ls)
    return ops, y

def header(d, s, sl, dark=False, w=None):
    ops = []; w = w or int(CW * 0.85)
    if sl.get("eyebrow"):
        ops.append(tb(s, M, EYEBROW_Y, w, 274320, sl["eyebrow"].upper(), 12, C["white"] if dark else C["ink"],
                      bold=True, ls=1.5, name="eyebrow"))
    y = TITLE_Y
    if sl.get("title"):
        op, h = text_lines(d, s, "title", sl["title"], 24, M, y, w, C["coral"] if dark else C["coral_text"], 2, name="slide title")
        ops.append(op); y += h
    return ops, y

def page_no(s, dark=False):
    return tb(s, W - M - 640080, H - M - 274320, 640080, 274320, str(s + 1), 12,
              C["mist"] if dark else C["slate"], align="right", name="page number")

def source(s, text, dark=False):
    return tb(s, M, H - M - 274320, int(CW * 0.78), 274320, text, 12, C["mist"] if dark else C["slate"], name="source")

def lockup(d, s, x, y, h=320040):
    return image(s, d.asset("logos/lt-group-company-lockup-white.png"), x, y, int(h * LT_RATIO), h,
                 "A Larsen & Toubro Group Company", name="L&T endorsement")

def logo(d, s, h=377190):
    w = int(h * LOGO_RATIO)
    return image(s, d.asset("logos/ltm-logo-coral.png"), W - M - w, H - M - h, w, h, "LTM logo", name="LTM logo")

# ------------------------------------------------------------------ layouts
def L_cover(d, s, sl):
    d.image_ground[s] = d.asset("backgrounds/ltm-wave-cover-ink.jpg")
    x, cx = 838200, 9144000
    ops = [lockup(d, s, M, H - M - 320040), logo(d, s)]
    o, y = display(d, s, [(sl["title"], C["white"])], 54, x, 1463040, cx, 3, name="cover title"); ops += o
    if sl.get("subtitle"):
        op, h = text_lines(d, s, "subtitle", sl["subtitle"], 24, x, y + 91440, cx, C["white"], 2, name="cover subtitle"); ops.append(op); y += 91440 + h
    if sl.get("meta"):   # 18pt white = large text, readable over the coral ribbon
        op, h = text_lines(d, s, "meta", sl["meta"], 18, x, y + 45720, cx, C["white"], 2, name="cover meta"); ops.append(op)
    return ops

def L_closing(d, s, sl):
    d.image_ground[s] = d.asset("backgrounds/ltm-wave-cover-black.jpg")
    ops = [lockup(d, s, M, M), logo(d, s)]
    x = 3200400; y = 1463040
    ops.append(tb(s, x, y, W - M - x, int(60 * PT), sl.get("lead", "It\u2019s time to"), 60, C["white"], name="closing lead"))
    ex = x + 1143000; emph = sl.get("emphasis", "Outcreate")
    d.lines(s, "closing emphasis", emph, 96, W - M - ex, 1)
    ops.append(tb(s, ex, y + int(60 * PT), W - M - ex, int(96 * PT), emph, 96, C["white"], name="closing emphasis"))
    if sl.get("contact"):
        op, _ = text_lines(d, s, "contact", sl["contact"], 14, M, H - M - bh(2, 14), int(CW * 0.5), C["mist"], 2, name="contact"); ops.append(op)
    return ops

def L_section(d, s, sl):
    d.ground[s] = C["ink"]
    iw = int(W * 0.46); ih = int(iw * 947 / 1105)
    ops = [image(s, d.asset("backgrounds/ltm-wave-corner-ink-br.png"), W - iw, H - ih, iw, ih, name="particle wave")]
    if sl.get("number"):
        ops.append(tb(s, M, EYEBROW_Y, 2743200, 274320, sl["number"], 14, C["coral"], bold=True, ls=1.5, name="section number"))
    o, y = display(d, s, [(sl["title"], C["white"])], 54, M, TITLE_Y, int(CW * 0.7), 2, name="section title"); ops += o
    if sl.get("subtitle"):
        op, _ = text_lines(d, s, "subtitle", sl["subtitle"], 20, M, y + 91440, int(CW * 0.6), C["mist"], 3, name="section subtitle"); ops.append(op)
    return ops                                      # dividers carry no page number

def L_statement(d, s, sl):
    d.ground[s] = C["cloud"]
    cw_ = int(W * 1269 / 1920); ch_ = int(cw_ * 710 / 1269)
    ops = [image(s, d.asset("backgrounds/ltm-wave-corner-cloud.png"), W - cw_, 0, cw_, ch_, name="particle wave")]
    if sl.get("eyebrow"):
        ops.append(tb(s, M, EYEBROW_Y, int(CW * 0.5), 274320, sl["eyebrow"].upper(), 12, C["ink"], bold=True, ls=1.5, name="eyebrow"))
    o, _ = display(d, s, [(sl.get("lead", ""), C["coral_text"]), (sl.get("rest", ""), C["ink"])], 44, M, TITLE_Y, 6949440, 5, name="statement"); ops += o
    if sl.get("support"):
        cx = 5029200; ls = d.lines(s, "support", sl["support"], 18, cx, 7)
        ops.append(tb(s, W - M - cx, BOTTOM - bh(len(ls), 18), cx, bh(len(ls), 18), sl["support"], 18, C["ink"], name="support"))
    ops.append(page_no(s))
    return ops

def L_manifesto(d, s, sl):
    d.ground[s] = C["ink"]
    iw = int(W * 1105 / 1920); ih = int(iw * 947 / 1105)
    ops = [image(s, d.asset("backgrounds/ltm-wave-corner-ink.png"), 0, 0, iw, ih, name="particle wave")]
    ghost = sl.get("ghost", ["Outthink.", "Outperform.", "Out-imagine.", "Out-evolve."])[:4]
    x = int(W * 0.45)
    o, _ = display(d, s, [(g, C["graphite"]) for g in ghost], 60, x, 594360, W - M - x, 4, name="ghost words"); ops += o
    lead = sl.get("lead", "It\u2019s time to"); emph = sl.get("emphasis", "Outcreate.")
    cx = min(CW, int(max(len(lead), len(emph)) * 66 * PT * 0.61) + 365760)
    h = bh(2, 66, 1.18)
    o, _ = display(d, s, [(lead, C["white"]), (emph, C["coral"])], 66, M, H - M - h, cx, 2, name="call to action"); ops += o
    return ops

def L_agenda(d, s, sl):
    d.ground[s] = C["cloud"]; sl = dict(sl); sl.setdefault("eyebrow", "Agenda")
    x = int(W * 0.42); cx = W - M - x
    ops, _ = header(d, s, sl, w=x - M - G)
    items = sl["items"][:6]; row = int((BOTTOM - TITLE_Y) / max(len(items), 4)); y0 = TITLE_Y
    for i, it in enumerate(items):
        yy = y0 + i * row
        ops.append(tb(s, x, yy, 914400, bh(1, 28), f"{i + 1:02d}", 28, C["coral_text"]))
        op, _ = text_lines(d, s, f"agenda item {i + 1}", it, 22, x + 1005840, yy + (bh(1, 28) - bh(1, 22)) // 2, cx - 1005840, C["ink"], 1)
        ops.append(op)
        ops.append(shape(s, "rect", x, yy + bh(1, 28) + 91440, cx, 12700, C["rule"]))
    ops.append(page_no(s))
    return ops

def L_context_cards(d, s, sl):
    d.ground[s] = C["cloud"]
    cards = sl["cards"][:5]; n = len(cards); cw = (CW - (n - 1) * G) // n
    size = 20 if n <= 3 else 16
    bar_h = 640080 if sl.get("bar") else 0
    bar_y = BOTTOM - bar_h
    ch = 2286000; cy0 = (bar_y - 228600 if bar_h else BOTTOM) - ch
    ops = [image(s, d.card(f"s{s}-card{i}", cw, ch), M + i * (cw + G), cy0, cw, ch, name=f"card {i + 1}") for i in range(n)]
    hops, y = header(d, s, sl); ops += hops
    if sl.get("intro"):
        op, _ = text_lines(d, s, "intro", sl["intro"], 16, M, y + 45720, int(CW * 0.5), C["ink"], 3, name="intro"); ops.append(op)
    wrapped = [d.lines(s, f"card {i + 1}", t, size, cw - 182880, 5) for i, t in enumerate(cards)]
    mx = max(len(w) for w in wrapped)
    for i, ls in enumerate(wrapped):
        x = M + i * (cw + G)
        ops.append(tb(s, x + 91440, cy0 + 182880, cw - 182880, bh(mx, size), padded(ls, mx), size, C["ink"]))
    if bar_h:
        d.lines(s, "bar", sl["bar"], 20, CW - 457200, 1)
        ops.append(shape(s, "roundRect", M, bar_y, CW, bar_h, C["coral"], sl["bar"], 20, C["white"], name="so-what bar"))
    ops.append(page_no(s))
    return ops

def L_pillars(d, s, sl):
    d.ground[s] = C["cloud"]
    ps = sl["pillars"][:3]; n = len(ps); cw = (CW - (n - 1) * G) // n; ch = 3200400; cy0 = BOTTOM - ch
    looks = [(C["coral"], C["ink"]), (C["ink"], C["white"]), (C["white"], C["ink"])]   # small text on coral is ink
    ops = [image(s, d.card(f"s{s}-pillar{i}", cw, ch, "solid", looks[i % 3][0]), M + i * (cw + G), cy0, cw, ch, name=f"pillar {i + 1}") for i in range(n)]
    hops, y = header(d, s, sl); ops += hops
    if sl.get("intro"):
        op, _ = text_lines(d, s, "intro", sl["intro"], 16, M, y + 45720, int(CW * 0.5), C["ink"], 3, name="intro"); ops.append(op)
    iw = cw - 274320
    titles = [d.lines(s, f"pillar {i + 1} title", p["title"], 20, iw, 2, 0.66) for i, p in enumerate(ps)]
    texts = [d.lines(s, f"pillar {i + 1} text", p["text"], 16, iw, 5) for i, p in enumerate(ps)]
    mt = max(len(t) for t in titles); mx = max(len(t) for t in texts)
    for i, p in enumerate(ps):
        fill, fg = looks[i % 3]; x = M + i * (cw + G) + 137160
        ops.append(tb(s, x, cy0 + 137160, iw, bh(1, 40), f"{i + 1:02d}", 40, fg))
        ops.append(tb(s, x, cy0 + 137160 + bh(1, 40), iw, bh(mt, 20), padded(titles[i], mt), 20, fg, bold=True))
        ops.append(tb(s, x, cy0 + ch - 182880 - bh(mx, 16), iw, bh(mx, 16), padded(texts[i], mx), 16, fg))
    ops.append(page_no(s))
    return ops

def L_shifts(d, s, sl):
    d.ground[s] = C["cloud"]; ops = []
    if sl.get("eyebrow"):
        ops.append(tb(s, M, EYEBROW_Y, int(CW * 0.6), 274320, sl["eyebrow"].upper(), 12, C["ink"], bold=True, ls=1.5, name="eyebrow"))
    o, y = display(d, s, [(sl.get("lead", ""), C["ink"]), (sl.get("emphasis", ""), C["coral_text"])], 44, M, TITLE_Y, CW, 3, name="headline"); ops += o
    rows = sl["shifts"][:3]; pw = 4937760; ph = 548640; aw = 548640
    gap = (CW - 2 * pw - aw) // 2
    top = max(y + 365760, 3017520); step = (BOTTOM - top) // 3
    for i, (a, b) in enumerate(rows):
        yy = top + i * step
        for label, txt in (("from", a), ("to", b)):
            d.lines(s, f"shift {i + 1} {label}", txt, 20, int(pw * 0.9), 1)
        ops.append(shape(s, "flowChartTerminator", M, yy, pw, ph, C["white"], a, 20, C["ink"]))
        ops.append(shape(s, "rightArrow", M + pw + gap, yy + ph // 2 - 114300, aw, 228600, C["coral"]))
        ops.append(shape(s, "flowChartTerminator", M + pw + 2 * gap + aw, yy, pw, ph, C["white"], b, 20, C["ink"]))
    ops.append(page_no(s))
    return ops

def L_stats(d, s, sl):
    d.ground[s] = C["white"]
    lx_w = 3931920
    gx = M + lx_w + G; gw = W - M - gx; gy = M; gh = BOTTOM - M
    tiles = [("stat", st) for st in sl["stats"][:4]]
    if sl.get("endorsement"):
        tiles.insert(1, ("endorse", None))                  # L&T tile top-right, as in LTM's own deck
    tiles = tiles[:4]
    cols = 2 if len(tiles) > 2 else len(tiles); rows = 2 if len(tiles) > 2 else 1
    tw = (gw - (cols - 1) * G) // cols; th = (gh - (rows - 1) * G) // rows
    fills = [C["black"], C["steel"], C["coral"], C["cloud"]]
    ops = []; texts = []; k = 0
    for i, (kind, st) in enumerate(tiles):
        r, c = divmod(i, cols); x = gx + c * (tw + G); yt = gy + r * (th + G)
        if kind == "endorse":
            ops.append(image(s, d.card(f"s{s}-tile{i}", tw, th, "solid", C["ltblue"]), x, yt, tw, th, name="L&T tile"))
            lh = 365760; lw = int(lh * LT_RATIO)
            ops.append(lockup(d, s, x + (tw - lw) // 2, yt + (th - lh) // 2, lh))
            continue
        fill = fills[k % len(fills)]; k += 1
        fg = C["ink"] if fill in (C["coral"], C["cloud"]) else C["white"]
        ops.append(image(s, d.card(f"s{s}-tile{i}", tw, th, "solid", fill), x, yt, tw, th, name=f"stat tile {i + 1}"))
        size = 66 if th > 2286000 else 54
        d.lines(s, f"stat {i + 1} value", st["value"], size, tw - 228600, 1)
        texts.append(tb(s, x + 114300, yt + 91440, tw - 228600, bh(1, size), st["value"], size, fg))
        op, h = text_lines(d, s, f"stat {i + 1} label", st["label"], 20, x + 114300, 0, tw - 228600, fg, 2)
        op["y"] = int(yt + th - 91440 - h); texts.append(op)
    hops, _ = header(d, s, sl, w=lx_w); ops += hops + texts
    yy = int(H * 0.45)
    if sl.get("lead"):
        op, h = text_lines(d, s, "lead", sl["lead"], 16, M, yy, lx_w, C["ink"], 2); ops.append(op); yy += h
    if sl.get("emphasis"):
        o, yy = display(d, s, [(sl["emphasis"], C["coral_text"])], 32, M, yy, lx_w, 3); ops += o
    if sl.get("tail"):
        op, h = text_lines(d, s, "tail", sl["tail"], 16, M, yy + 45720, lx_w, C["ink"], 4); ops.append(op)
    ops.append(page_no(s))
    return ops

def L_cards(d, s, sl):
    ground = sl.get("ground", "white"); d.ground[s] = C[ground]
    cs = sl["cards"][:4]; n = len(cs); cw = (CW - (n - 1) * G) // n; ch = 2834640; cy0 = BOTTOM - ch
    ops = [image(s, d.card(f"s{s}-card{i}", cw, ch, "frost", ground="cloud" if ground == "cloud" else "white"),
                 M + i * (cw + G), cy0, cw, ch, name=f"card {i + 1}") for i in range(n)]
    hops, y = header(d, s, sl); ops += hops
    if sl.get("intro"):
        op, _ = text_lines(d, s, "intro", sl["intro"], 16, M, y + 45720, int(CW * 0.55), C["ink"], 3, name="intro"); ops.append(op)
    iw = cw - 274320; ts = 20 if n <= 3 else 18
    titles = [d.lines(s, f"card {i + 1} title", c["title"], ts, iw, 2) for i, c in enumerate(cs)]
    texts = [d.lines(s, f"card {i + 1} text", c["text"], 14, iw, 5) for i, c in enumerate(cs)]
    mt = max(len(t) for t in titles); mx = max(len(t) for t in texts)
    text_y = cy0 + ch - 137160 - bh(mx, 14); title_y = text_y - 45720 - bh(mt, ts)
    if title_y < cy0 + 137160 + bh(1, 28):
        d.warn.append(f"slide {s + 1}: cards are too full - shorten titles or texts")
    for i, c in enumerate(cs):
        x = M + i * (cw + G) + 137160
        ops.append(tb(s, x, cy0 + 137160, 914400, bh(1, 28), f"{i + 1:02d}", 28, C["coral_text"]))
        ops.append(tb(s, x, title_y, iw, bh(mt, ts), padded(titles[i], mt), ts, C["ink"]))
        ops.append(tb(s, x, text_y, iw, bh(mx, 14), padded(texts[i], mx), 14, C["ink"]))
    ops.append(page_no(s))
    return ops

def L_offerings(d, s, sl):
    d.ground[s] = C["cloud"]
    of = sl["offerings"][:3]; n = len(of); cw = (CW - (n - 1) * G) // n; ch = 2286000; cy0 = int(H * 0.36)
    ops = [image(s, d.card(f"s{s}-off{i}", cw, ch), M + i * (cw + G), cy0, cw, ch, name=f"offering {i + 1}") for i in range(n)]
    hops, _ = header(d, s, sl); ops += hops
    texts = [d.lines(s, f"offering {i + 1} text", o["text"], 14, cw - 457200, 4) for i, o in enumerate(of)]
    mx = max(len(t) for t in texts)
    for i, o in enumerate(of):
        x = M + i * (cw + G)
        d.lines(s, f"offering {i + 1} name", o["name"], 36, cw - 228600, 1)
        ops.append(tb(s, x + 114300, cy0 + 320040, cw - 228600, bh(1, 36), o["name"], 36, C["ink"], align="center"))
        ops.append(tb(s, x + 228600, cy0 + 320040 + bh(1, 36) + 91440, cw - 457200, bh(mx, 14), padded(texts[i], mx), 14, C["ink"], align="center"))
    if sl.get("caption"):
        cap = sl["caption"]; cap_w = min(CW - 1828800, int(len(cap) * 20 * PT * 0.61) + 365760)
        by = cy0 + ch + 457200; side = (CW - cap_w) // 2 - 91440
        ops.append(shape(s, "rect", M, by, side, 25400, C["coral"], name="bracket left"))
        ops.append(shape(s, "rect", W - M - side, by, side, 25400, C["coral"], name="bracket right"))
        ops.append(tb(s, M + (CW - cap_w) // 2, by - bh(1, 20) // 2, cap_w, bh(1, 20), cap, 20, C["ink"], align="center", name="caption"))
    ops.append(page_no(s))
    return ops

def L_bar_compare(d, s, sl):
    d.ground[s] = C["white"]; ops, y = header(d, s, sl)
    rows = sl["rows"][:7]; has_prior = any("prior" in r for r in rows)
    vmax = max(max(r["current"], r.get("prior", 0)) for r in rows) or 1
    lab_w = 3017520; x0 = M + lab_w; bar_w_max = int(CW * 0.60) - lab_w
    top = y + 320040; legend_y = BOTTOM - 274320; avail = legend_y - 182880 - top
    row_h = avail // len(rows); bar_h = min(int(row_h * (0.34 if has_prior else 0.55)), 320040)
    unit = sl.get("unit", "")
    vals = [r["current"] for r in rows] + [r["prior"] for r in rows if "prior" in r]
    dec = max((len(str(v).split(".")[1]) if "." in str(v) else 0) for v in vals)
    fmt = lambda v: f"{v:,.{dec}f}{unit}"
    vw = 822960
    for i, r in enumerate(rows):
        yy = top + i * row_h
        op, h = text_lines(d, s, f"row {i + 1} label", r["label"], 14, M, yy, lab_w - 91440, C["ink"], 2); ops.append(op)
        cw_ = max(int(bar_w_max * r["current"] / vmax), 12700)
        ops.append(shape(s, "rect", x0, yy + 45720, cw_, bar_h, C["coral"]))
        ops.append(tb(s, x0 + cw_ + 45720, yy + 45720 + bar_h // 2 - 137160, vw, 274320, fmt(r["current"]), 12, C["ink"], bold=True))
        if "prior" in r:
            pw = max(int(bar_w_max * r["prior"] / vmax), 12700); py = yy + 45720 + bar_h + 27432
            ops.append(shape(s, "rect", x0, py, pw, bar_h, C["prior"]))
            ops.append(tb(s, x0 + pw + 45720, py + bar_h // 2 - 137160, vw, 274320, fmt(r["prior"]), 12, C["slate"]))
    ops.append(shape(s, "rect", M, legend_y + 68580, 137160, 137160, C["coral"]))
    ops.append(tb(s, M + 182880, legend_y, 1828800, 274320, sl.get("current_label", "Current"), 12, C["ink"]))
    if has_prior:
        ops.append(shape(s, "rect", M + 2103120, legend_y + 68580, 137160, 137160, C["prior"]))
        ops.append(tb(s, M + 2286000, legend_y, 1828800, 274320, sl.get("prior_label", "Prior"), 12, C["ink"]))
    if sl.get("takeaway"):
        tx = M + int(CW * 0.68); tw = W - M - tx
        ls = d.lines(s, "takeaway", sl["takeaway"], 22, tw - 182880, 7)
        ops.append(shape(s, "rect", tx, top, 38100, bh(len(ls), 22), C["coral"], name="takeaway rule"))
        ops.append(tb(s, tx + 182880, top, tw - 182880, bh(len(ls), 22), sl["takeaway"], 22, C["ink"], name="takeaway"))
    if sl.get("source"): ops.append(source(s, sl["source"]))
    ops.append(page_no(s))
    return ops

def L_table(d, s, sl):
    d.ground[s] = C["white"]; ops, y = header(d, s, sl)
    hdr = sl["header"]; rows = sl["rows"][:10]
    cells = [list(map(str, hdr))] + [[str(c) for c in r] for r in rows]
    top = y + 320040; tw = int(CW * 0.64) if sl.get("takeaway") else CW
    row_h = min(411480, (BOTTOM - top) // len(cells))
    ops.append({"op": "add_table", "slide": s, "x": M, "y": int(top), "cx": tw, "cy": int(row_h * len(cells)),
                "rows": len(cells), "cols": len(hdr), "cells": cells, "header": True,
                "headerFill": C["coral"], "headerColor": C["white"], "sizePt": 12 if len(cells) > 7 else 14, "fontFamily": FONT})
    if sl.get("takeaway"):
        tx = M + tw + 457200; tww = W - M - tx
        ls = d.lines(s, "takeaway", sl["takeaway"], 22, tww - 182880, 8)
        ops.append(shape(s, "rect", tx, top, 38100, bh(len(ls), 22), C["coral"], name="takeaway rule"))
        ops.append(tb(s, tx + 182880, top, tww - 182880, bh(len(ls), 22), sl["takeaway"], 22, C["ink"], name="takeaway"))
    if sl.get("source"): ops.append(source(s, sl["source"]))
    ops.append(page_no(s))
    return ops

def L_case_study(d, s, sl):
    d.ground[s] = C["white"]; ops = []
    lw = int(CW * 0.40); px = M + lw + G; pw = W - px; ph = int(H * 0.52)
    by = int(H * 0.56); bw = (CW - 2 * G) // 3; bhh = BOTTOM - by
    if sl.get("image"):
        ops.append(image(s, sl["image"], px, 0, pw, ph, sl.get("image_alt", "Case study image"), name="case image", fit="cover"))
    else:
        d.warn.append(f"slide {s + 1}: case_study has no image - add a real photo or a generated one (imagery recipe)")
    looks = ["frost", "frost", "coral"]
    for i, look in enumerate(looks):
        x = M + i * (bw + G)
        art = d.card(f"s{s}-cs{i}", bw, bhh, "solid", C["coral"]) if look == "coral" else d.card(f"s{s}-cs{i}", bw, bhh, "frost", ground="white")
        ops.append(image(s, art, x, by, bw, bhh, name=["Challenge", "Approach", "Impact"][i]))
    if not sl.get("image"):
        ops.append(shape(s, "rect", px, 0, pw, ph, C["cloud"], name="image placeholder"))
    if sl.get("eyebrow"):
        ops.append(tb(s, M, EYEBROW_Y, lw, 274320, sl["eyebrow"].upper(), 12, C["ink"], bold=True, ls=1.5, name="eyebrow"))
    op, h = text_lines(d, s, "title", sl["title"], 28, M, TITLE_Y, lw, C["ink"], 3, name="slide title"); ops.append(op)
    op, _ = text_lines(d, s, "context", sl["context"], 14, M, TITLE_Y + h + 91440, lw, C["ink"], 5); ops.append(op)
    blocks = [("Challenge", sl["challenge"]), ("Approach", sl["approach"]), ("Impact", "\n".join("\u2192 " + t for t in sl["impact"]))]
    for i, (lab, txt) in enumerate(blocks):
        x = M + i * (bw + G) + 137160; coral = looks[i] == "coral"
        ops.append(tb(s, x, by + 91440, bw - 274320, 304800, lab.upper(), 14, C["ink"] if coral else C["coral_text"], bold=True, ls=1))
        ls = d.lines(s, f"{lab} text", txt, 14, bw - 274320, 8)
        ops.append(tb(s, x, by + 91440 + 304800, bw - 274320, bh(len(ls), 14), txt, 14, C["ink"]))
    ops.append(page_no(s))
    return ops

def L_quote(d, s, sl):
    d.ground[s] = C["cloud"]
    cw_ = int(W * 1269 / 1920); ch_ = int(cw_ * 710 / 1269)
    ops = [image(s, d.asset("backgrounds/ltm-wave-corner-cloud.png"), W - cw_, 0, cw_, ch_, name="particle wave")]
    cx = int(CW * 0.66); ls = d.lines(s, "quote", "\u201c" + sl["quote"] + "\u201d", 32, cx, 5)
    qh = bh(len(ls), 32); who = [sl["name"]] + ([sl["role"]] if sl.get("role") else [])
    total = qh + 91440 + bh(len(who), 14); qy = (H - total) // 2 + 228600
    ops.append(shape(s, "rect", M, qy, 63500, total, C["coral"], name="quote rule"))
    ops.append(tb(s, M + 365760, qy, cx, qh, "\n".join(ls), 32, C["ink"], name="quote"))
    ops.append(tb(s, M + 365760, qy + qh + 91440, cx, bh(len(who), 14), "\n".join(who), 14, C["slate"], name="attribution"))
    ops.append(page_no(s))
    return ops

def L_timeline(d, s, sl):
    d.ground[s] = C["cloud"]; ops, y = header(d, s, sl)
    st = sl["steps"][:6]; n = len(st); ly = int(H * 0.50); seg = CW // n
    ops.append(shape(s, "rect", M, ly, CW, 25400, C["ink"], name="timeline axis"))
    whats = [d.lines(s, f"step {i + 1}", p["what"], 14, seg - 137160, 5) for i, p in enumerate(st)]
    mx = max(len(w) for w in whats)
    for i, p in enumerate(st):
        cxn = M + seg * i + seg // 2; dot = 228600
        ops.append(shape(s, "ellipse", cxn - dot // 2, ly + 12700 - dot // 2, dot, dot, C["coral"]))
        ops.append(tb(s, M + seg * i + 45720, ly - 182880 - bh(1, 16), seg - 91440, bh(1, 16), p["when"], 16, C["coral_text"], bold=True, align="center"))
        ops.append(tb(s, M + seg * i + 68580, ly + 274320, seg - 137160, bh(mx, 14), padded(whats[i], mx), 14, C["ink"], align="center"))
    ops.append(page_no(s))
    return ops

def L_logo_wall(d, s, sl):
    d.ground[s] = C["ink"]
    ps = sl["partners"][:20]; cols = 5; rows = (len(ps) + cols - 1) // cols
    hops, y = header(d, s, sl, dark=True)
    band_top = y + 274320; cw = CW // cols
    rh = min((BOTTOM - band_top) // max(rows, 1), 1188720)
    top = band_top + (BOTTOM - band_top - rows * rh) // 2
    pics, rest = [], []
    for i, p in enumerate(ps):
        r, c = divmod(i, cols); x = M + c * cw; yy = top + r * rh
        if c: rest.append(shape(s, "rect", x, yy + 91440, 12700, rh - 182880, C["graphite"]))
        if r: rest.append(shape(s, "rect", x + 91440, yy, cw - 182880, 12700, C["graphite"]))
        if p.get("logo"):
            lx, ly, lw, lh = contain(p["logo"], x + 228600, yy + 182880, cw - 457200, rh - 640080)
            pics.append(image(s, p["logo"], lx, ly, lw, lh, p["name"] + " logo"))
        else:
            rest.append(tb(s, x + 91440, yy + 228600, cw - 182880, bh(1, 20), p["name"], 20, C["white"], align="center"))
        if p.get("note"):
            ls = d.lines(s, f"{p['name']} note", p["note"], 12, cw - 182880, 2)
            rest.append(tb(s, x + 91440, yy + rh - 91440 - bh(2, 12), cw - 182880, bh(2, 12), padded(ls, 2), 12, C["mist"], align="center"))
    return pics + hops + rest + [page_no(s, True)]

def L_recognitions(d, s, sl):
    d.ground[s] = C["ink"]; ops, y = header(d, s, sl, dark=True)
    it = sl["items"][:9]; cols = 3; rows = math.ceil(len(it) / cols); cw = (CW - 2 * G) // cols
    band_top = y + 365760; rh = min((BOTTOM - band_top) // rows, 1554480)
    top = band_top + (BOTTOM - band_top - rows * rh) // 2
    for i, t in enumerate(it):
        r, c = divmod(i, cols); x = M + c * (cw + G); yy = top + r * rh
        ops.append(shape(s, "star8", x, yy, 365760, 365760, C["coral"]))
        ls = d.lines(s, f"recognition {i + 1}", t, 14, cw - 548640, 6)
        ops.append(tb(s, x + 502920, yy - 45720, cw - 548640, bh(len(ls), 14), t, 14, C["white"]))
    ops.append(page_no(s, True))
    return ops

def L_photo_statement(d, s, sl):
    d.ground[s] = C["ink"]
    ops = [image(s, sl["image"], 0, 0, W, H, sl.get("image_alt", "Photograph"), name="photo", fit="cover"),
           shape(s, "rect", 0, 0, W, H, {"color": C["ink"], "alpha": 45}, name="scrim")]
    hops, _ = header(d, s, sl, dark=True); ops += hops
    o, _ = display(d, s, [(sl["statement"], C["white"])], 40, M, int(H * 0.52), int(CW * 0.5), 4, name="statement"); ops += o
    if sl.get("support"):
        x = M + int(CW * 0.55); cx = W - M - x; ls = d.lines(s, "support", sl["support"], 20, cx, 6)
        ops.append(tb(s, x, BOTTOM - bh(len(ls), 20), cx, bh(len(ls), 20), sl["support"], 20, C["white"], name="support"))
    ops.append(page_no(s, True))
    return ops

BUILD = {k[2:]: v for k, v in dict(globals()).items() if k.startswith("L_")}

def images_first(ops):
    """The live engine creates a picture written after any shape of its slide on TOP of every shape.
    Writing all pictures first (in their own order) keeps cards and waves under the text."""
    return [o for o in ops if o["op"] == "add_image"] + [o for o in ops if o["op"] != "add_image"]

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan"); ap.add_argument("--out", default="working/ltm-deck")
    ap.add_argument("--layouts", action="store_true")
    a = ap.parse_args()
    if a.layouts or not a.plan:
        for k, v in LAYOUTS.items(): print(f"{k:16s} {v}")
        return
    plan = json.load(open(a.plan)); slides = plan["slides"]
    os.makedirs(a.out, exist_ok=True); d = Deck(a.out); batches = {}
    for s, sl in enumerate(slides):
        lay = sl.get("layout")
        if lay not in BUILD: sys.exit(f"unknown layout '{lay}' on slide {s + 1} (run --layouts)")
        ops = images_first(BUILD[lay](d, s, sl))
        if sl.get("notes"): ops.append({"op": "set_notes", "slide": s, "text": sl["notes"]})
        batches[s] = ops
    calls = []
    def write(name, ops, purpose):
        p = os.path.join(a.out, name); json.dump(ops, open(p, "w"), indent=1)
        calls.append({"patches_file": rel(p), "purpose": purpose, "ops": len(ops)})
    calls.append({"patches": [{"op": "set_slide_size", "preset": "16:9"}], "purpose": "16:9 canvas (own call, first)"})
    if 0 in d.image_ground:
        write("01-ground-s00.json", [{"op": "set_slide_background", "path": rel(d.image_ground[0]), "slides": [0]}], "cover ground image")
    elif 0 in d.ground:
        write("01-ground-s00.json", [{"op": "set_slide_background", "fill": d.ground[0], "slides": [0]}], "cover ground")
    write("02-slide-00.json", batches[0], f"slide 1 ({slides[0]['layout']})")
    if len(slides) > 1:
        write("03-add-slides.json", [{"op": "add_slide"} for _ in range(len(slides) - 1)], f"add {len(slides) - 1} slides")
        by = {}
        for s, f in d.ground.items():
            if s: by.setdefault(f, []).append(s)
        if by:
            write("04-grounds.json", [{"op": "set_slide_background", "fill": f, "slides": sorted(v)} for f, v in by.items()], "solid grounds")
        for s, p in sorted(d.image_ground.items()):
            if s: write(f"05-ground-s{s:02d}.json", [{"op": "set_slide_background", "path": rel(p), "slides": [s]}], f"slide {s + 1} ground image")
        group, count, gi = [], 0, 0      # content batches of <= ~120 ops, whole slides only
        for s in range(1, len(slides)):
            if group and count + len(batches[s]) > 120:
                gi += 1; write(f"10-content-{gi:02d}.json", [o for t in group for o in batches[t]], f"slides {group[0] + 1}-{group[-1] + 1}")
                group, count = [], 0
            group.append(s); count += len(batches[s])
        if group:
            gi += 1; write(f"10-content-{gi:02d}.json", [o for t in group for o in batches[t]], f"slides {group[0] + 1}-{group[-1] + 1}")
    for s in range(len(slides)):          # per-slide files too, for targeted rebuilds
        json.dump(batches[s], open(os.path.join(a.out, f"slide-{s + 1:02d}.json"), "w"), indent=1)
    man = {"title": plan.get("title"), "slides": len(slides), "calls": calls, "fit_warnings": d.warn}
    json.dump(man, open(os.path.join(a.out, "manifest.json"), "w"), indent=1)
    print(json.dumps({"calls": [c.get("patches_file", "inline set_slide_size") for c in calls], "fit_warnings": d.warn}, indent=1))

if __name__ == "__main__":
    main()
