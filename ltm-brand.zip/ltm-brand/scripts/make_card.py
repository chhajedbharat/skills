#!/usr/bin/env python3
"""Rounded LTM card artwork for slides.

The live PowerPoint engine cannot set a roundRect's corner radius (it always uses a sixth of the
shorter side), so large LTM cards - which have a small ~9.5pt corner - are placed as PNG artwork
at the card's exact size, with native text boxes on top. This is also how LTM's own corporate
deck builds its cards.

Styles
  frost  : LTM's soft "frosted" card - a gentle diagonal grey gradient, a touch lighter than the
           Cloud Grey (E9E9E9) slide ground. Use --ground white for cards on white slides.
  solid  : flat fill in any brand colour (coral FF5E4F, ink 1A1A1A, white FFFFFF, steel 559BB5,
           L&T blue 004B88, black 000000) - numbered pillar cards, stat tiles, CTA bars.

Single card:
  python make_card.py --w-emu 3759200 --h-emu 2540000 --style solid --fill FF5E4F --out working/card-coral.png
Batch (JSON list of {name, w_emu, h_emu, style?, fill?, ground?, radius_pt?}):
  python make_card.py --spec working/cards.json --outdir working/cards
"""
import argparse, json, os
import numpy as np
from PIL import Image, ImageDraw

EMU_PER_IN = 914400

def hex2rgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def card(w_emu, h_emu, style="frost", fill="FFFFFF", ground="cloud", radius_pt=9.5, ppi=200):
    w_in, h_in = w_emu / EMU_PER_IN, h_emu / EMU_PER_IN
    W, H = max(8, round(w_in * ppi)), max(8, round(h_in * ppi))
    ss = 4
    r = radius_pt / 72 * ppi * ss
    mask = Image.new("L", (W * ss, H * ss), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W * ss - 1, H * ss - 1], radius=r, fill=255)
    mask = mask.resize((W, H), Image.LANCZOS)
    if style == "solid":
        body = Image.new("RGB", (W, H), hex2rgb(fill))
    else:
        # frosted: diagonal gradient, darker top-left -> lighter bottom-right (sampled from LTM deck cards)
        a, b = ((0xEC, 0xEC, 0xEC), (0xF6, 0xF6, 0xF6)) if ground == "cloud" else ((0xF1, 0xF1, 0xF1), (0xF8, 0xF8, 0xF8))
        yy, xx = np.mgrid[0:H, 0:W]
        t = ((xx / max(W - 1, 1)) + (yy / max(H - 1, 1))) / 2.0          # 0 top-left -> 1 bottom-right
        rgb = np.stack([a[i] + (b[i] - a[i]) * t for i in range(3)], -1)
        body = Image.fromarray(np.round(rgb).astype(np.uint8), "RGB")
    body.putalpha(mask)
    return body

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--w-emu", type=int); ap.add_argument("--h-emu", type=int)
    ap.add_argument("--style", default="frost", choices=["frost", "solid"])
    ap.add_argument("--fill", default="FFFFFF"); ap.add_argument("--ground", default="cloud", choices=["cloud", "white"])
    ap.add_argument("--radius-pt", type=float, default=9.5)
    ap.add_argument("--ppi", type=int, default=200)
    ap.add_argument("--out"); ap.add_argument("--spec"); ap.add_argument("--outdir", default="working/cards")
    a = ap.parse_args()
    if a.spec:
        os.makedirs(a.outdir, exist_ok=True)
        for c in json.load(open(a.spec)):
            img = card(c["w_emu"], c["h_emu"], c.get("style", a.style), c.get("fill", a.fill),
                       c.get("ground", a.ground), c.get("radius_pt", a.radius_pt), a.ppi)
            p = os.path.join(a.outdir, c["name"] + ".png"); img.save(p, optimize=True); print("saved", p, img.size)
    else:
        if not (a.w_emu and a.h_emu and a.out):
            ap.error("give --w-emu, --h-emu and --out, or --spec")
        img = card(a.w_emu, a.h_emu, a.style, a.fill, a.ground, a.radius_pt, a.ppi)
        img.save(a.out, optimize=True); print("saved", a.out, img.size)

if __name__ == "__main__":
    main()
