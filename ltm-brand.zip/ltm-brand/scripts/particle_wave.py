#!/usr/bin/env python3
"""LTM particle-wave generator.

Creates on-brand "particle ribbon" artwork (the flowing coral dust ribbon used on
LTM covers, closers and statement slides) at any size, so covers for A4 reports,
banners or square social tiles do not have to stretch the 16:9 originals.

Pure numpy + Pillow. No network access.

Examples
  python particle_wave.py --preset cover   --width 1920 --height 1080 --out working/wave-cover.jpg
  python particle_wave.py --preset corner  --width 1600 --height 900  --bg cloud --out working/wave-corner.png
  python particle_wave.py --preset band    --width 2400 --height 800  --out working/wave-banner.jpg
  python particle_wave.py --preset portrait --width 1240 --height 1754 --out working/a4-cover.jpg
  python particle_wave.py --preset cover --bg transparent --out working/wave.png   # alpha PNG

Backgrounds: ink (1A1A1A, default), black (000000), cloud (E9E9E9), white, coral, transparent,
or any 6-digit hex. Particle colour defaults to LTM Coral FF5E4F (use --color FFFFFF for a
white ribbon on a coral ground).
"""
import argparse, math
import numpy as np
from PIL import Image

NAMED = {"ink": "1A1A1A", "black": "000000", "cloud": "E9E9E9", "white": "FFFFFF",
         "coral": "FF5E4F", "graphite": "3D3D3D"}

def hex2rgb(h):
    h = NAMED.get(h, h).lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

# Each preset: centre-line control points (fractions of W,H), max half-width (fraction of H),
# twist turns, dust side (+1 above / -1 below), density multiplier.
PRESETS = {
    # diagonal ribbon rising from lower-left to upper-right (LTM cover / closer)
    "cover":    dict(pts=[(-0.15, 0.95), (0.25, 0.70), (0.55, 0.42), (0.80, 0.20), (1.15, 0.02)],
                     width=0.20, twist=0.55, dust=+1, density=1.0),
    # ribbon sweeping into the top-right corner (light statement slides)
    "corner":   dict(pts=[(0.45, -0.10), (0.68, 0.02), (0.86, 0.22), (0.97, 0.48), (1.08, 0.80)],
                     width=0.13, twist=0.55, dust=-1, density=1.4),
    # ribbon entering from the top-left corner (dark manifesto slides)
    "corner-tl": dict(pts=[(-0.10, 0.62), (0.05, 0.40), (0.20, 0.18), (0.38, 0.02), (0.55, -0.12)],
                     width=0.12, twist=0.55, dust=+1, density=1.4),
    # low horizontal band (web banners, report section headers)
    "band":     dict(pts=[(-0.10, 0.80), (0.20, 0.62), (0.50, 0.70), (0.80, 0.52), (1.10, 0.60)],
                     width=0.26, twist=0.70, dust=+1, density=1.0),
    # tall format (A4 / letter report cover): ribbon crossing the lower two-thirds
    "portrait": dict(pts=[(-0.25, 0.95), (0.10, 0.80), (0.45, 0.66), (0.80, 0.50), (1.25, 0.38)],
                     width=0.085, twist=0.45, dust=+1, density=1.2),
}

def catmull(pts, n):
    """Catmull-Rom spline through pts -> (n,2) array plus unit tangents."""
    P = np.array(pts, float)
    P = np.vstack([P[0] * 2 - P[1], P, P[-1] * 2 - P[-2]])
    segs = len(P) - 3
    t = np.linspace(0, segs, n, endpoint=False)
    i = np.floor(t).astype(int); s = (t - i)[:, None]
    p0, p1, p2, p3 = P[i], P[i + 1], P[i + 2], P[i + 3]
    pos = 0.5 * ((2 * p1) + (-p0 + p2) * s + (2 * p0 - 5 * p1 + 4 * p2 - p3) * s ** 2 + (-p0 + 3 * p1 - 3 * p2 + p3) * s ** 3)
    der = 0.5 * ((-p0 + p2) + 2 * (2 * p0 - 5 * p1 + 4 * p2 - p3) * s + 3 * (-p0 + 3 * p1 - 3 * p2 + p3) * s ** 2)
    der /= np.linalg.norm(der, axis=1, keepdims=True) + 1e-9
    return pos, der

def _ribbon(rng, pos, tan, nrm, u, H, half_frac, twist, phase, n, dust_side, dust_amt):
    """Sample one translucent particle sheet. Returns points (k,2) and per-particle alpha (k,)."""
    n_curve = len(u)
    half = half_frac * H * (0.35 + 0.65 * np.sin(np.pi * np.clip(u, 0, 1)) ** 0.6)
    theta = 2 * np.pi * twist * u + phase
    app = half * (0.30 + 0.70 * np.abs(np.cos(theta)))      # folds narrow the sheet, never pinch it shut
    shift = half * 0.35 * np.sin(theta)                     # sheet drifts as it turns -> overlapping folds
    idx = rng.integers(0, n_curve, n)
    v = rng.uniform(-1, 1, n)
    p = pos[idx] + nrm[idx] * (v * app[idx] + shift[idx])[:, None]
    p += rng.normal(0, 0.6, (n, 2))                          # crisp silhouette
    a = rng.uniform(0.35, 0.85, n)
    # dust lifts off one edge as distinct specks
    nd = int(n * dust_amt)
    di = rng.integers(0, n_curve, nd)
    dist = rng.exponential(0.035 * H, nd) * (0.3 + np.sin(np.pi * u[di]) ** 2)
    edge = pos[di] + nrm[di] * (dust_side * app[di] + shift[di])[:, None]
    dp = edge + nrm[di] * (dust_side * dist)[:, None] + tan[di] * rng.normal(0, 0.015 * H, nd)[:, None]
    da = rng.uniform(0.5, 1.0, nd) * np.exp(-dist / (0.08 * H))
    return np.vstack([p, dp]), np.concatenate([a, da])

def render(width, height, preset="cover", bg="ink", color="FF5E4F", seed=7, density=1.0, ss=1):
    cfg = PRESETS[preset]
    rng = np.random.default_rng(seed)
    W, H = width, height
    n_curve = 6000
    pts = [(x * W, y * H) for x, y in cfg["pts"]]
    pos, tan = catmull(pts, n_curve)
    nrm = np.stack([-tan[:, 1], tan[:, 0]], 1)
    u = np.linspace(0, 1, n_curve)
    # particle budget scales with the ribbon's area so density looks the same at any size
    length = np.sum(np.linalg.norm(np.diff(pos, axis=0), axis=1))
    area = length * 2 * cfg["width"] * H * 0.6
    base_n = area * 1.6 * density * cfg["density"]
    side = cfg["dust"]
    ph = rng.uniform(0, np.pi)
    layers = [  # (half-width x, twist x, phase offset, share, dust)
        (1.00, 1.00, 0.0, 0.50, 0.10),   # main sheet
        (0.62, 1.20, 1.1, 0.30, 0.04),   # inner fold, dense core
        (1.22, 0.80, 2.3, 0.35, 0.14),   # outer veil, airy
    ]
    P, A = [], []
    for hx, tx, po, share, dust in layers:
        pts_, a_ = _ribbon(rng, pos, tan, nrm, u, H, cfg["width"] * hx, cfg["twist"] * tx, ph + po,
                           int(base_n * share), side, dust)
        P.append(pts_); A.append(a_)
    nf = int(base_n * 0.002)                                   # a whisper of far dust
    fi = rng.integers(0, n_curve, nf)
    P.append(pos[fi] + rng.normal(0, 0.10 * H, (nf, 2))); A.append(np.full(nf, 0.6))
    P = np.vstack(P); A = np.concatenate(A)
    x = np.round(P[:, 0]).astype(int); y = np.round(P[:, 1]).astype(int)
    ok = (x >= 0) & (x < W) & (y >= 0) & (y < H)
    acc = np.zeros(H * W, np.float32)
    np.add.at(acc, y[ok] * W + x[ok], A[ok])
    alpha = 1 - np.exp(-acc.reshape(H, W) * 2.0)
    a8 = Image.fromarray((np.clip(alpha, 0, 1) * 255).astype(np.uint8), "L")
    col = Image.new("RGBA", (width, height), hex2rgb(color) + (255,))
    col.putalpha(a8)
    if bg == "transparent":
        return col
    ground = Image.new("RGBA", (width, height), hex2rgb(bg) + (255,))
    ground.alpha_composite(col)
    return ground.convert("RGB")

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--preset", default="cover", choices=sorted(PRESETS))
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--bg", default="ink", help="ink|black|cloud|white|coral|transparent|RRGGBB")
    ap.add_argument("--color", default="FF5E4F", help="particle colour, default LTM Coral")
    ap.add_argument("--seed", type=int, default=7, help="change for a different ribbon")
    ap.add_argument("--density", type=float, default=1.0)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    img = render(a.width, a.height, a.preset, a.bg, a.color, a.seed, a.density)
    if a.out.lower().endswith((".jpg", ".jpeg")):
        img.convert("RGB").save(a.out, quality=90, optimize=True)
    else:
        img.save(a.out, optimize=True)
    print(f"saved {a.out} {a.width}x{a.height} preset={a.preset} bg={a.bg}")

if __name__ == "__main__":
    main()
