# LTM Slide Layouts and Storylines

`scripts/ltm_deck.py` builds every layout below as live PowerPoint patch batches. Each one
reproduces an archetype from LTM's corporate deck. See `layout-gallery.jpg` for the rendered set
and `sample-plan.json` for a complete 18-slide plan. Any slide may add `"notes": "..."` for
sources or presenter notes.

## Layout catalogue

| Layout | LTM archetype / when to use | Fields (limits) |
|---|---|---|
| `cover` | Dark particle-wave cover with L&T endorsement and LTM logo. Every deck opens with it. | `title` (≤3 lines at 54pt, about 20 chars per line), `subtitle?`, `meta?` (date or presenter) |
| `agenda` | Numbered coral list on Cloud | `title?`, `items[]` (≤6, one line each) |
| `section` | Ink divider with a corner wave. Use between acts. | `number?` ("02"), `title`, `subtitle?` |
| `statement` | Light big-idea slide with a coral lead word and a particle corner | `eyebrow?`, `lead` (coral), `rest` (ink), `support?` (≤7 lines) |
| `context_cards` | "Our industry is at an inflection point": 2-5 frosted statement cards and a coral so-what bar | `eyebrow?`, `title`, `intro?`, `cards[]` (≤12 words each), `bar?` (one line) |
| `pillars` | Three numbered solid cards (coral, ink, white) | `eyebrow?`, `title`, `intro?`, `pillars[3]` ({title ≤2 words-ish, text ≤20 words}) |
| `shifts` | "LTM is the Business Creativity partner": from → to pills | `eyebrow?`, `lead`, `emphasis`, `shifts[]` (≤3 pairs, ≤26 chars each) |
| `stats` | "LTM at a glance": 2-4 KPI tiles, optional L&T tile, emphasis copy left | `eyebrow?`, `title`, `lead?`, `emphasis?`, `tail?`, `stats[]` ({value, label}), `endorsement?` |
| `cards` | Values or principles: 3-4 frosted cards with a coral number, title and text | `eyebrow?`, `title`, `intro?`, `cards[]` ({title, text ≤25 words}), `ground?` (white or cloud) |
| `offerings` | iRun / iTransform / Business AI: 3 centred cards with a bracket caption | `eyebrow?`, `title`, `offerings[3]` ({name, text}), `caption?` |
| `bar_compare` | Annual-report bar chart: current coral, prior grey, with a takeaway | `eyebrow?`, `title`, `unit?`, `current_label`, `prior_label?`, `rows[]` (≤7 {label, current, prior?}), `takeaway?`, `source?` |
| `table` | Coral header band, coral-wash banding, takeaway | `eyebrow?`, `title`, `header[]`, `rows[][]` (≤10), `takeaway?`, `source?` |
| `case_study` | Annual-report case study: title, context, photo, challenge / approach / impact | `eyebrow?` (industry), `title`, `context`, `challenge`, `approach`, `impact[]` (≤3 bullets), `image?`, `image_alt?` |
| `quote` | Leader or client quote with a coral rule and particle corner | `quote` (≤5 lines), `name`, `role?` |
| `timeline` | Phased plan on a single axis with coral nodes | `eyebrow?`, `title`, `steps[]` (3-6 {when, what}) |
| `logo_wall` | Dark partner ecosystem grid (names, or official logo files) | `eyebrow?`, `title`, `partners[]` (≤20 {name, logo?, note?}) |
| `recognitions` | Dark awards grid with coral stars | `eyebrow?`, `title`, `items[]` (≤9) |
| `manifesto` | "Outthink. Outperform. Out-imagine. Out-evolve. It's time to Outcreate." | `ghost[]?`, `lead?`, `emphasis?` |
| `photo_statement` | Full-bleed photo with a scrim and a white statement ("Our belief") | `eyebrow?`, `title?`, `statement`, `support?`, `image` |
| `closing` | Black particle-wave closer: "It's time to Outcreate" with the logos | `lead?`, `emphasis?`, `contact?` |

Rules of thumb: alternate compositions (never three card slides in a row); one dark slide every
4-6 slides at most; keep at least one data or proof slide per act; finish with `manifesto` and/or
`closing`.

## Storylines

**1. Corporate introduction ("LTM at a glance")**, 14-18 slides: cover → agenda →
context_cards (industry inflection) → shifts (LTM is the Business Creativity partner) → pillars
→ statement (Outcreate) → stats → cards (values) → section → offerings → logo_wall →
recognitions → manifesto → closing. This is the `sample-plan.json` flow.

**2. Client pitch or proposal**, 10-14 slides, persuasive arc: cover (client and opportunity)
→ context_cards (the client's situation, sourced) → statement (our point of view) → shifts
(from today to target state) → pillars or offerings (how we'll do it, each part tied to a
benefit) → case_study (proof) → stats (why LTM) → bar_compare or table (business case, sourced)
→ timeline (plan) → closing with the ask in `contact` (for example "Next step: 2-week discovery
sprint, w/c 10 Nov").

**3. QBR or account review**, 8-12 slides: cover → agenda → stats (KPIs against target) →
bar_compare (trend) → table (SLA detail) → case_study (wins this quarter) → context_cards (risks
and asks, so-what bar) → timeline (next quarter) → closing.

**4. Capability or solution deck**, 10-14 slides: cover → statement (market point of view) →
context_cards (need) → offerings → pillars (differentiators) → timeline (engagement model) →
case_study ×2 → logo_wall (partners relevant to the solution) → recognitions → closing.

**5. Internal town hall**, 8-12 slides: cover → manifesto → stats (year in numbers) → cards
(values in action) → section → timeline (priorities) → quote (leader) → photo_statement (people)
→ closing.

## Copy limits that keep slides on-brand

- Headlines 3-8 words; card statements up to 12 words; pillar texts up to 20 words; body blocks
  up to 40 words.
- Numbers are written as figure and unit ("87k+", "USD 4.76bn", "+11.3%"), with the period and
  source in notes.
- If the builder reports a fit warning, shorten the words. Do not shrink the type.
