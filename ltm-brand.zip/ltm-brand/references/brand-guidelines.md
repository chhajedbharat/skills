# LTM Brand Guidelines (distilled)

Sources: *LTM Corporate Deck / Media Kit* (Feb 2026, 18 slides, 1920×1080pt canvas),
*LTM Integrated Annual Report 2025-26* (May 2026, 275 pages, Adobe InDesign) and the ltm.com
partners banner. All values below were measured from those files. Screen and print values differ
slightly; use the screen values for slides, documents and web.

## 1. Identity and architecture

- **Master brand:** LTM. Legal entity in statutory or financial contexts: *LTM Limited*.
- **History:** formerly LTIMindtree. The renaming and rebranding happened in FY26. Mention the
  old name only to explain the change; never show the old logo or colours.
- **Endorsement:** "A Larsen & Toubro Group Company" lockup (L&T symbol + divider + two-line
  text). It sits on the cover (bottom-left on slides, top-left on report covers) and on the
  closing slide (top-left).
- **Positioning:** *The Business Creativity partner*. **Brand idea and line:** *It's time to
  Outcreate.*
- **Platform names:** BlueVerse (agentic AI ecosystem). Offerings: iRun, iTransform, Business AI.

## 2. Logo

| File | Use on |
|---|---|
| `assets/logos/ltm-logo-coral.svg/.png` | Ink `1A1A1A` or black grounds (primary, as on the cover) and white |
| `assets/logos/ltm-logo-ink.svg/.png` | White, Cloud `E9E9E9` and light photos |
| `assets/logos/ltm-logo-white.svg/.png` | Coral fills, dark photos, Steel or L&T Blue tiles |
| `assets/logos/lt-group-company-lockup-white` / `-ink` | Endorsement on dark / light grounds |

- Wordmark proportion **3.8 : 1** (width : height). Lockup **5.26 : 1**.
- **Size:** on a 16:9 slide the LTM logo is about 0.41in tall (≈1.6in wide), placed 0.5in from the
  right and bottom edges. Minimum: 0.5in (12mm) wide in print, 72px on screen.
- **Clear space:** at least half the logo's height on every side; nothing else enters it.
- **Placement:** cover and closing slide only (LTM's corporate deck carries no logo on interior
  slides). Report covers: L&T lockup top-left, LTM logo top-right.
- **Don't:** redraw or retype it, stretch or rotate it, recolour it outside the three variants,
  add shadows, glows or outlines, put it in a box, set it on busy imagery without a scrim, or lock
  it up with a tagline or another logo.

## 3. Colour

| Role | Name | Hex | RGB | Use |
|---|---|---|---|---|
| Accent | **LTM Coral** | `FF5E4F` | 255 94 79 | Fills, bars, arrows, icons, waves, so-what bar, coral stat tile, coral type on dark grounds |
| Accent (text on light) | **Coral Text** | `E2463A` | 226 70 58 | Coral *words* on White/Cloud/card grounds (titles, numbers, labels). 4.06:1 on white, 3.35:1 on Cloud |
| Ink | **Ink** | `1A1A1A` | 26 26 26 | Body text, dark slides, pillar card, table text |
| Ground | **Cloud Grey** | `E9E9E9` | 233 233 233 | Default light slide ground |
| Ground | **White** | `FFFFFF` | | Data, table, case-study and stat slides; cards on Cloud |
| Dark | **Black** | `000000` | | Closing slide ground; stat tile |
| Ghost | **Graphite** | `3D3D3D` | 61 61 61 | Ghost words on ink (decorative only) |
| Secondary | **Steel Blue** | `559BB5` | 85 155 181 | Stat tile, chart series 4 |
| Secondary | **L&T Blue** | `004B88` | 0 75 136 | L&T endorsement tile; L&T parent content |
| Neutral | **Slate** | `57585B` | | Secondary text, sources, captions on light |
| Neutral | **Mist** | `ACA9A9` | | Captions and page numbers on dark |
| Data | **Prior Grey** | `CCCBCA` | | Prior-period bars (annual report style) |
| Data | **Rule Grey** | `D1D2D4` | | Hairlines and dividers |
| Tint | **Coral Wash** | `FEF2ED` | | Table banding, highlight rows |
| Tint | **Coral Tint** | `FCD3C6` | | Stronger banding and fills in reports |
| ESG only | **ESG Green** `35754E`, **Sage** `9AAF9C` | | | Sustainability sections of reports only |

Print equivalents in the annual report: Coral `F15F53`, Ink `191919`. Do not mix them into
screen work.

**Proportion:** neutrals (Ink, Cloud, White) carry about 75% of any page; Coral about 15-20%;
secondary blues stay under 5% and appear only as tiles or data. One accent hue per slide: never
introduce a second bright colour.

**Contrast (WCAG, computed):**

| Pair | Ratio | Verdict |
|---|---|---|
| Ink on White / on Cloud | 17.4 / 14.3 | All text |
| White on Ink | 17.4 | All text |
| Coral `FF5E4F` on Ink / on Black | 5.77 / 6.97 | All text |
| Coral `FF5E4F` on White | 3.01 | Large text only (≥18pt, or ≥14pt bold) |
| Coral `FF5E4F` on Cloud | 2.48 | **Graphics only, never text**: use Coral Text |
| Coral Text `E2463A` on White / Cloud / card F2F2F2 | 4.06 / 3.35 / 3.63 | Headings and large labels |
| Ink on Coral | 5.77 | All text (stat tile, pillar card, impact card) |
| White on Coral | 3.01 | ≥18pt only (so-what bar) |
| White on Steel / Ink on Steel | 3.11 / 5.59 | Large / all |
| White on L&T Blue | 8.89 | All text |
| Slate on White / Cloud | 7.11 / 5.86 | All text |
| Mist on Ink | 7.46 | All text |
| Graphite on Ink | 1.60 | Decorative ghost words only |

## 4. Typography

- **Brand face:** *ES Klarheit Grotesk* (licensed). Deck: **Book** for everything large and most
  body text, **Semibold** for eyebrows, pillar titles and page numbers, Regular for small body.
  Report: Book and Regular body, Medium, Semibold, Bold and Extrabold for labels and figures.
- **Office and live engine:** **Arial**, the only safe neutral grotesk that renders true. Web:
  `"ES Klarheit Grotesk", "Helvetica Neue", Arial, sans-serif`.
- Headlines are **never bold**. Use sentence case. Leading is very tight on display type (about
  0.85-0.9 in Klarheit; use 1.0-1.18 in Arial). The emphasis colour does the work, not the weight.

**Slide type scale** (LTM deck measured on 1920pt → standard 13.33in slide; builder value):

| Element | LTM deck | Standard slide | Builder |
|---|---|---|---|
| Manifesto line ("It's time to Outcreate.") | 174pt | 87pt | 66pt |
| Stat figure (87k+) | 153pt | 76pt | 54-66pt |
| Statement headline | 128pt | 64pt | 44pt |
| Cover title | 115pt | 58pt | 54pt |
| Big headline ("LTM is the …") | 96pt | 48pt | 44pt |
| Pillar number (01) | 83pt | 42pt | 40pt |
| Emphasis line (human insights …) | 64pt | 32pt | 32pt |
| Card statement | 41pt | 20pt | 16-20pt |
| Coral section title | 36pt | 18pt | 24pt |
| Body / intro | 24-29pt | 12-14pt | 14-16pt |
| Eyebrow (CAPS, Semibold) | 16pt | 8pt | 12pt bold, tracked 1.5pt |
| Page number | 16pt | 8pt | 12pt |

The builder lifts small sizes to a 12pt floor and stays slightly below LTM's display sizes
because Arial sets wider than Klarheit.

**Documents:** title 28pt regular; H1 22-24pt Coral Text regular; H2 14pt bold Ink; H3 11pt bold
Coral Text; body 10.5pt; captions and sources 8-9pt Slate. The report's running footer reads
"LTM Limited | Integrated Annual Report 2025-26" on the left and "It's time to Outcreate" on the
right, with bold page numbers.

## 5. Layout

- **Canvas:** 16:9. LTM's own margin is 40/1920 (≈0.28in); the builder uses a 0.5in safe margin.
- **Header:** small CAPS eyebrow (the section name, for example CONTEXT, WHY WE'RE DIFFERENT,
  WHO WE ARE) with a coral section title directly beneath, top-left, identical on every
  interior slide.
- **Composition:** generous empty space at the top; the content (cards, pills, tiles) is anchored
  to the lower half. A light slide carries one idea.
- **Rhythm:** light Cloud or White content slides, punctuated by Ink slides for dividers,
  partners, recognition and the manifesto, framed by the dark particle-wave cover and closer.
- **Page numbers:** bottom-right on content slides; none on cover, dividers, manifesto or closer.

## 6. Graphic devices

- **Particle wave:** a flowing ribbon of coral particles with a dusty, dissolving edge. Full-bleed
  on Ink (cover) or Black (closer); a corner accent on light statement slides (top-right);
  top-left on dark manifesto slides; a low band on web banners. Never recolour it to
  non-brand hues. White-on-coral is allowed for a single hero moment.
- **Cards:** about 9.5pt corner radius at slide scale (19px on the 1920 canvas). *Frosted* cards
  run a soft diagonal F0F0F0→F6F6F6 gradient on Cloud. *Solid* cards come in Coral, Ink or White
  (numbered pillars) and Black, Steel, Coral or L&T Blue (stat tiles).
- **Pills and arrows:** white stadium pills with Ink text and a Coral arrow between "from" and
  "to" (the shifts layout).
- **So-what bar:** a full-width rounded Coral bar with a single white line of 18pt or more.
- **Bracket caption:** thin Coral rules either side of a centred caption ("Business Creativity in
  action").
- **Icons:** simple filled or line pictograms in Coral (heart, people, compass, bar chart, bulb,
  brain, globe, ID badge, handshake); one weight and one colour; a Coral 8-point star with an
  inner star for awards.
- **Arrows in copy:** Coral `→` bullets in reports and case studies.
- **Maps:** grey world map with Coral location dots and Coral label tabs.

## 7. Imagery

- **Photography:** cinematic and real. Cool blue-teal technology environments (data centres,
  labs, modern offices) with one warm accent, and people at work (diverse, natural, candid).
  Industry scenes (banking, retail, energy, healthcare, manufacturing, travel) use natural light.
  The report favours warm, human, community photography.
- **Avoid:** handshake clichés, glowing robot brains, binary rain, staged stock smiles, heavy
  filters, duotones in non-brand colours.
- **Text on photos:** only over a 45% Ink scrim, or in a clear dark area.
- **Generated images:** stylised and clearly illustrative for people; never presented as real
  LTM employees, clients or events.

## 8. Data visualisation

- Current period in Coral `FF5E4F`; prior period in Prior Grey `CCCBCA`; further series in Ink,
  Steel, then L&T Blue.
- Horizontal bars by default (as in the annual report MD&A), with values at the bar ends: current
  bold Ink, prior regular Slate. No gridlines, no 3D. Legend squares bottom-left. Unit label such
  as "(%)" top-right.
- Tables: Coral header band with white bold text; rows on white with Coral Wash `FEF2ED` banding;
  subtotal rows `EAEBEC`; numbers right-aligned; source line 8-12pt Slate below.
- Big-number KPI tiles: figure (54-76pt) top-left, label (18-22pt) bottom-left, optional icon
  bottom-right.
