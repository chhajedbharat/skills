# LTM Brand in Other Formats

The deck recipe was built and checked on the live PowerPoint engine. The recipes below apply the
same tokens through each format's own skill; verify each by rendering before delivery.

## Word documents (docx skill, live surface)

- `set_theme{accent:"E2463A", ink:"1A1A1A", muted:"57585B"}` once, right after creation, so
  Title, Heading 1-3 and Accent-1 table styles take the brand.
- Cover block, top of page 1: insert `assets/backgrounds/ltm-wave-doc-banner.jpg` at full text
  width (8:3, so a 6.5in width needs 2.44in height; give both widthEmu and heightEmu on live).
  Then an eyebrow line (9pt bold CAPS Coral Text, for example "PROPOSAL" or "WHITE PAPER"), the
  title (28pt Arial regular, Ink), the subtitle (14pt Slate), a date or owner line (10pt Slate),
  and `assets/logos/ltm-logo-coral.png` at about 1.2in wide. Page break.
- Body Arial 10.5pt Ink. H1 22-24pt Coral Text regular. H2 14pt bold Ink. H3 11pt bold Coral
  Text. Pull quotes 14pt Coral Text. Lists use plain bullets or numbering.
- Tables: style `LightShading-Accent1` for reports or `MediumShading1-Accent1` for a solid coral
  header. Source line underneath, 8-9pt Slate.
- Header: `LTM | <Document title>` (live applies headers, not footers).
- Do not put the logo in running headers of long reports. Keep it to the cover.

## Excel workbooks (xlsx skill)

- Arial 10 or 11 everywhere. Row 1 title 18pt regular Ink; row 2 subtitle or source 10pt Slate.
- Header band: fill `1A1A1A`, font white bold, bottom border Coral `FF5E4F` (2pt). For a lighter
  look, fill Coral with **Ink** text.
- Banding with Coral Wash `FEF2ED` or none; totals row bold on `FEF2ED`; subtotals `EAEBEC`.
- Negative numbers in Coral Text `E2463A`; percentages with one decimal; thousands separators.
- Charts: series Coral `FF5E4F`, `CCCBCA`, `1A1A1A`, `559BB5`, `004B88`; no 3D; gridlines off or
  `D1D2D4`; data labels Ink; chart titles 12pt regular Ink.
- Freeze the header, size the columns, colour a summary sheet's tab Coral.

## HTML pages and Loop/Pages content

```css
:root{
  --ltm-coral:#FF5E4F; --ltm-coral-text:#E2463A; --ltm-ink:#1A1A1A; --ltm-cloud:#E9E9E9;
  --ltm-white:#FFFFFF; --ltm-slate:#57585B; --ltm-mist:#ACA9A9; --ltm-steel:#559BB5;
  --ltm-lt-blue:#004B88; --ltm-wash:#FEF2ED; --ltm-radius:12px;
  --ltm-font:"ES Klarheit Grotesk","Helvetica Neue",Arial,sans-serif;
}
body{font-family:var(--ltm-font);color:var(--ltm-ink);background:var(--ltm-white);}
.eyebrow{font-size:12px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;}
h1,h2{font-weight:400;letter-spacing:-.01em;line-height:1.02;}
h2{color:var(--ltm-coral-text);}
.dark h2{color:var(--ltm-coral);}
.card{background:linear-gradient(135deg,#F0F0F0,#F6F6F6);border-radius:var(--ltm-radius);padding:24px;}
.bar{background:var(--ltm-coral);color:#fff;border-radius:var(--ltm-radius);padding:14px 24px;font-size:20px;}
.hero{background:#1A1A1A url(data:image/jpeg;base64,...) center/cover;color:#fff;}
```

- Inline the logo SVG from `assets/logos/ltm-logo-coral.svg` (dark sections) or `-ink.svg`
  (light sections). Base64-embed `ltm-wave-cover-ink.jpg` or `ltm-banner-ink.jpg` for heroes.
- Sections alternate White and Cloud, with one Ink band for the closing call to action.

## Email (Outlook)

- Table layout, inline CSS, and every background set with both `bgcolor` and CSS. No external
  images: a text "LTM" mark in Coral `#FF5E4F`, bold, letter-spaced, stands in for the logo.
  Body Arial 14-15px Ink, headings regular weight, Coral Text for emphasis, and a Coral button
  with Ink or white text 16px or larger.
- Follow the existing `ltm-renewals-email` skill's conventions for renewal-style notices.

## Images (image generation)

Style suffix to reuse verbatim in prompts:

> cinematic photograph, real enterprise setting, cool blue-teal ambient light with a single warm
> coral (#FF5E4F) accent, shallow depth of field, subject on one third with calm negative space
> for text, premium and understated; no text, no words, no letters, no logos, no watermarks, no
> cartoon, no 3D render

- People: diverse professionals at work, natural expressions, stylised or illustrative when
  generated; never claim they are LTM staff or clients.
- Icons: transparent PNG, single Coral `#FF5E4F` glyph, simple rounded geometry, one weight,
  no text, no gradients.
- Abstract brand art: use `scripts/particle_wave.py` rather than generating new "waves".

## Social and banner sizes (particle_wave.py presets)

| Format | Size | Preset |
|---|---|---|
| Web hero / LinkedIn banner | 1584×396 or 1920×720 | `band` |
| Event screen 16:9 | 1920×1080 | `cover` |
| Square post | 1080×1080 | `cover` (seed varies) |
| A4 report cover | 1240×1754 | `portrait` |
| Light statement accent | any | `corner` with `--bg cloud` or `transparent` |
