# LTM Voice, Messaging and Proof Points

Sources: LTM Corporate Deck / Media Kit (Feb 2026); LTM Integrated Annual Report 2025-26 (FY26 =
April 2025 to March 2026, published May 2026). **Proof points are dated. Refresh them from the
latest official LTM publications before external use, and cite the source in speaker notes or a
source line.**

## 1. The narrative (the corporate storyline)

1. **Context: our industry is at an inflection point.** AI has moved from experimentation to
   execution. Technology and business are no longer separable. Clients are demanding outcomes,
   not services. Fragmented delivery models are breaking under pressure. *This is reshaping how
   value is created. And who creates it.*
2. **Belief:** *In the Agentic Enterprise era, technology alone is not enough.* Clients want
   partners who combine technology depth with strong domain expertise to enhance value creation
   and confidently own outcomes. *We call this Business Creativity.*
3. **Position:** *LTM is the Business Creativity partner.* The shifts: from solving problems to
   delivering outcomes; from tech-enabled to tech-domain convergence; from technology services to
   Business Creativity.
4. **What we do for the world's largest and most disruptive enterprises:** **Think disruptively**
   (challenging legacy models, assumptions and operating norms); **Reframe industries**
   (converging technology and domain expertise to unlock new productivity paradigms and paths to
   value); **Own outcomes** (executing with rigor and accountability, not just delivery).
5. **The advantage:** *Outcreate* is the ability to out-think, out-solve, out-imagine and
   out-evolve. *So that you don't simply outperform the market, you Outcreate it.*
6. **Sign-off:** *It's time to Outcreate.*

## 2. Vocabulary and usage

| Term | Rule |
|---|---|
| LTM | Always "LTM". Use "LTM Limited" only in legal and financial text. Never "LTIMindtree" except "formerly LTIMindtree". |
| A Larsen & Toubro Group Company | Endorsement wording exactly as written. "Larsen & Toubro" in full, with the ampersand. |
| Business Creativity | Capitalised as the brand concept. "the Business Creativity partner" (lowercase "partner"). |
| Outcreate | Capitalised as the brand idea or line ("It's time to Outcreate."). As a verb in running copy the report also writes "outcreate" ("helping enterprises outcreate new operating models"). Industry lines use "Outcreating …". |
| Outcreators | LTM's associates ("embracing a creator's mindset to problem-solving"). |
| Agentic Enterprise era | Capitalised when used as the era name. |
| tech x domain | Lowercase with "x", for technology-domain convergence. |
| BlueVerse | LTM's agentic AI ecosystem: one word, capital V. |
| ReAImagining | Brand coinage in the capabilities line. Use it sparingly and as written. |

**Out- family:** Outthink. Outperform. Out-imagine. Out-evolve. (Hyphenated before vowels.)

## 3. Tone

- **Confident and outcome-first:** lead with the result, then the how.
- **Short declaratives with rhythm:** "This is reshaping how value is created. And who creates it."
- **Parallel structures and triads:** "new ways of working, new productivity paradigms and new
  roads to value".
- **Contrast frames:** "outcomes, not services"; "not just delivery"; "from X to Y".
- **Human plus intelligent:** "the very best of human insights + intelligent systems".
- **Headlines:** sentence case, no full stop on titles (except brand lines), 3-8 words, state the
  takeaway. Eyebrows name the section in 1-3 CAPS words (CONTEXT, MARKET NEED, OUR CAPABILITIES,
  THE VALUE WE BRING).
- **Avoid:** empty superlatives without proof, buzzword stacks, exclamation marks, emojis, the old
  brand name, and claims about clients that are not public.

Headline patterns:
- "Outcreating <outcome>" (industries: "Outcreating patient care").
- "From <old> to <new>".
- "<Proof figure> <unit> <so-what>" ("90% lower cost per interaction").
- "<Brand idea> is the <benefit>" ("Outcreate is the advantage Business Creativity delivers").

## 4. Proof points (dated, sourced)

**LTM at a glance (Corporate Deck, Feb 2026):** 87k+ employees · 40+ countries · 700+ clients ·
117 offices · 100+ nationalities.
Regions (offices / delivery centres): North America 28 / 14 · Central America 1 / 1 ·
Europe 37 / 9 · Middle East & Africa 12 / 1 · India 50 / 42 · APAC 22 / 3.

**FY26 performance (Integrated Annual Report 2025-26):**
- Revenue USD 4,763.8 Million (+6.0% YoY); INR 423,076 Million (+11.3% YoY).
- Profit after tax INR 49,827 Million (+8.3%); return on equity 21.3%.
- 751 active clients (741 in FY25), including 125 Fortune 500 organisations; 79 new clients.
- Workforce about 88,000 across 40+ countries (Chairman's message).
- Revenue mix by industry, FY26 (FY25): BFSI 35.2% (36.1); Technology, Media & Communications
  23.0% (24.5); Manufacturing & Resources 20.2% (19.0); Consumer Business 15.3% (14.3);
  Healthcare, Life Sciences & Public Services 6.3% (6.1).
- Growth in USD by vertical: BFSI +3.7%; TMC -0.7%; M&R +12.7%; Consumer +13.2%;
  Healthcare, LS & PS +9.6%.
- Revenue by geography, FY26 (FY25): North America 73.4% (74.8); Europe 14.9% (14.1); Rest of
  World 11.7% (11.1). Growth: NA +4.0%, Europe +12.4%, RoW +11.6%.
- Sustainability and people: 94.41% waste recycled; CSR spend INR 960 Million; average learning
  13.01 days per employee.

**Case study (annual report, anonymised):** one of North America's largest banks (20M+ personal
banking and branded card customers, 46 retail partner clients). Contact-centre modernisation with
conversational and generative AI, voice agents and an agentic assistant with RAG search. Results:
90% cost reduction in straight-through processes (USD 12 to USD 0.7 per interaction); USD 6
Million annual OPEX savings (USD 3 Million in year one); zero call wait time with 90% intent
accuracy; improved CSAT and NPS.

**Corporate parent, Larsen & Toubro (Corporate Deck):** USD 31bn annual revenue (parent company
only) · 80+ years of experience · 200,000+ group employees · "a true nation-builder and the
largest engineering and construction company in India".

## 5. Content building blocks

**Values (What guides us):**
- *Be driven by purpose:* we lead with a clear mission to make technology and innovation work in
  the real world.
- *Act with compassion:* we build intimacy, warmth and empathy with stakeholders.
- *Be future-ready:* we enable businesses and communities to flourish by embracing change and
  reinvention.
- *Deliver impact:* we create tangible results and unlock new possibilities for clients and
  society.

**Strategic pivot (capabilities):** creating business solutions at the intersection of tech x
domain · ReAImagining capabilities powered by BlueVerse, our agentic ecosystem · global
expertise, local collaboration.

**Integrated model, "designed to Outcreate":** **iRun**, platformized, integrated tech operations
· **iTransform**, modernization and deployment of AI-ready technology and experiences ·
**Business AI**, responsible AI to redefine customers' tech stack for high-impact productivity.
Caption: *Business Creativity in action.*

**Industries, "Outcreating across industries":** Banking & Capital Markets: Outcreating
simplification · Insurance: Outcreating modernization · Retail-CPG: Outcreating consumer delight
· Communications, Media & Entertainment: Outcreating content experiences · Healthcare:
Outcreating patient care · Energy & Utilities: Outcreating energy security · Hi-Tech & Services:
Outcreating innovation-led growth · Life Sciences: Outcreating molecule-to-market journeys ·
Manufacturing: Outcreating manufacturing excellence · Travel, Transport & Hospitality:
Outcreating traveller experiences.

**Partners (Corporate Deck, Feb 2026):** Adobe (Solution Partner Platinum) · AWS (Restack & Top
Premier) · Boomi (Global Gold Partner) · Cisco · Databricks (Elite Partner) · Dell Technologies
(Gold Partner) · Duck Creek Technologies · Google Cloud (Premier Partner) · Hewlett Packard
Enterprise · IBM (Platinum Partner, amongst top 16 GSIs) · Informatica (one of 9 top GSIs) ·
Microsoft (Global ESI Partner) · NVIDIA (Preferred Partner) · Oracle (Platinum & MSP Partner) ·
Pega (Global Elite Partner) · Salesforce (Summit Partner) · SAP (among top 18 GSSPs) · ServiceNow
(among top 25 Elite Partners) · Snowflake (Platinum Tier) · UiPath.

**Recognitions (Corporate Deck, Feb 2026):**
- Market leader in HFS Horizons: energy and utility service providers 2025.
- A leader in Everest Group's Application Development Services for AI Applications PEAK Matrix
  assessment 2025.
- A leader in ISG Provider Lens Snowflake ecosystem partners 2025 (US).
- Visionary in the 2024 Gartner Magic Quadrant for Cloud ERP services.
- ISG Provider Lens Life Sciences Digital Services 2025: Leader in manufacturing supply chain,
  Rising Star in clinical development.
- Innovator in Avasant Life Sciences Digital Services 2025 RadarView.
- A leader in SAP S/4HANA system transformation (US and UK) in the ISG Provider Lens SAP
  ecosystem 2024 reports.
- "AMS SAP transformation partner of the year" (Tricentis) for RELY.
- "Organization with highest quality orientation" award, World Quality Congress & Awards.

**Leadership quotes (verbatim, annual report):**
- Venu Lambu, CEO and Managing Director: "In this AI-driven landscape, access to technology is no
  longer a differentiator."
- S. N. Subrahmanyan, Chairman: "Together, we Outcreate."
- Theme note: "LTM is more than a new name. It represents a leap forward and a clear call to
  action: It's time to Outcreate."
