---
name: ltm-brand
description: >
  Applies the LTM brand (formerly LTIMindtree, "A Larsen & Toubro Group Company") to any artifact:
  PowerPoint decks, Word documents, Excel workbooks, HTML pages, emails and images. Bundles the
  official logo artwork, the Coral FF5E4F / Ink 1A1A1A / Cloud E9E9E9 palette, the ES Klarheit
  Grotesk type scale (Arial in Office), particle-wave artwork, card styles, the "Business
  Creativity" / "Outcreate" voice with sourced proof points, and a slide builder for 20 LTM
  layouts tuned on the live PowerPoint engine. Use when the user asks for "an LTM deck", "LTM-branded", "in LTM brand", "make it
  look like the LTM corporate deck", "an LTM presentation / one-pager / report", or "check this
  against LTM brand guidelines". Do NOT use for other companies' brands, Larsen & Toubro
  group-level branding, or a deck the user supplies as a template (keep its own layouts).
metadata:
  category: writing
  icon: SlideLayout
---

# LTM Brand

A brand system distilled from LTM's own materials: the corporate deck / media kit (Feb 2026),
the Integrated Annual Report 2025-26 (May 2026) and the ltm.com partners banner. Colours, type
sizes, card radii and layouts were **measured from those files**, not guessed. The logos in
`assets/logos/` are exact vector rebuilds of the artwork embedded in the annual report. If the user
later supplies LTM's official brand-asset zip, prefer its files and keep everything else.

Paths below are relative to this skill's folder (installed copies usually live at
`/mnt/user-config/skills/ltm-brand/`; locate it with `find / -path '*ltm-brand/SKILL.md' 2>/dev/null`).

## When NOT to use

- Another company's brand, or Larsen & Toubro parent/group branding.
- The user attached an LTM deck or template to fill or update: follow the `pptx` skill's template
  modes (keep its masters and layouts). Use this skill only for voice, palette checks and
  `scripts/brand_check.py`.
- Plain analysis or chat answers with no branded deliverable.

## Brand essentials

| Element | Rule |
|---|---|
| Name | **LTM** (legal and financial contexts: LTM Limited). "Formerly LTIMindtree" only for history. Endorsement line: **A Larsen & Toubro Group Company**. |
| Positioning | *LTM is the Business Creativity partner*: technology and domain expertise converged, outcomes owned. Brand line: **It's time to Outcreate.** |
| Logo | Coral wordmark on Ink/black, Ink wordmark on white/light, White wordmark on coral or photos. Cover and closing only, bottom-right. L&T lockup bottom-left on covers, top-left on closers. Never redraw, stretch, recolour, add effects, or place on interior slides. |
| Colour | Field: Ink `1A1A1A`, Cloud `E9E9E9`, White (~75%). Accent: Coral `FF5E4F` (~15-20%, one accent only). Stat tiles only: Black `000000`, Steel `559BB5`, L&T Blue `004B88`. **Coral words on light grounds use Coral Text `E2463A`**. Small text on coral is Ink. |
| Type | ES Klarheit Grotesk: Book for headlines and body, Semibold for eyebrows. Office/live engine: **Arial**. Web: `"ES Klarheit Grotesk", "Helvetica Neue", Arial, sans-serif`. Headlines are never bold; sentence case; tight leading. |
| Motifs | Particle-wave ribbon (covers, closers, statement corners); frosted rounded cards (9.5pt radius); white pills with coral arrows; coral "so-what" bar; coral 8-point star for awards; coral `→` bullets. |
| Slide grammar | 12pt bold tracked CAPS eyebrow → coral 24pt section title, top-left, same x/y on every slide → content anchored low with generous air → page number bottom-right. Dark ink slides for dividers, partners, recognition and manifesto moments. |
| Voice | Confident, outcome-first, short declaratives; "from X to Y"; "not X, but Y"; triads; "Out-" verbs (Outthink. Outperform. Out-imagine. Out-evolve.). |

Full specification: `references/brand-guidelines.md`. Copy, vocabulary and dated proof points:
`references/voice-and-messaging.md`.

## Workflow

1. **Ground the content first.** Facts come from the user, their files, M365 search, or the dated
   proof points in `references/voice-and-messaging.md` (cite source and date in speaker notes or
   footnotes). Unknown figures become visible placeholders such as `[Add FY27 revenue]`.
2. **Shape the story before the design.** Pick a storyline from `references/slide-layouts.md`
   (corporate intro, client pitch, QBR, capability, town hall). One idea per slide; the
   headline states the takeaway; every claim slide carries a number, a proof point or a source.
3. **Build with the recipe for the artifact** (A–E below).
4. **QA**: render and look at every page, then run `python scripts/brand_check.py <file>`.
   Fix everything except the brand-intentional warnings listed under A.6.
5. **Deliver**: name the file exactly; list any placeholders or limitations in plain words.

### A. PowerPoint deck (tuned on the live engine)

1. Load the `pptx` skill (its live-engine rules apply), then create the deck on live:
   `host-CreateArtifact(surface="live", path="<Real Title>.pptx")`.
2. Write the plan JSON: `{"title": ..., "slides": [{"layout": "cover", ...}, ...]}`. Layouts and
   fields: `python scripts/ltm_deck.py --layouts`. Worked example: `references/sample-plan.json`.
   Visual reference: `references/layout-gallery.jpg`. Add `"notes"` to any slide for sources.
3. Build the patch batches into a **fresh folder name every time** (the workspace mount lags; a
   reused or recreated folder made the engine fail to find images):
   `python scripts/ltm_deck.py --plan working/plan.json --out working/ltm-build-<n>`.
   Fix every `fit_warnings` entry by shortening copy, then re-run into a new folder.
4. Apply `manifest.json` → `calls` in order: the inline `set_slide_size` first, then each
   `patches_file` with `host-EditArtifact(surface="live", path="file_N", patches_file=...)`.
   Per-slide files (`slide-NN.json`) let you rebuild one slide later.
5. Imagery: `case_study` and `photo_statement` take an `image` path. Use a real photo the user
   supplies, or generate one with the image tool (style suffix in `references/other-formats.md`),
   save it under `working/`, and set it in the plan before building.
6. QA: `host-GetArtifactModel(surface="live", render=true)` → `core-RenderArtifact` on the
   `renderPath` for all pages → open the images → `python scripts/brand_check.py <renderPath>`.
   Fix by deleting and re-adding shapes (z-order is creation order). Brand-intentional QA
   warnings you may leave: ground change/flip on dark divider, partner, recognition and manifesto
   slides; the low-contrast "ghost" words on the manifesto slide.

**Live-engine lessons (from building an 18-slide sample on the live engine; the builder applies
them, and the corrected layouts were re-verified in rendered previews):**
- A picture written after any text or shape of its slide is created on top of everything and
  hides the text. Write every picture of a slide first.
- `altText: ""` is refused. Omit alt text on decorative art; give logos and photos real alt text.
- Short labels are pre-wrapped with explicit breaks and balanced, so neither PowerPoint nor the
  QA re-wraps them. Display text stays in plain multi-line boxes (one per colour).
- Only Office fonts work: Arial stands in for ES Klarheit Grotesk. Never Calibri or Aptos.
- `roundRect` corners cannot be set, so large cards are PNG art (`scripts/make_card.py`).
- Do not name shapes `title`, `subtitle` or `body` (they resolve to placeholders).

### B. Word document

Load the `docx` skill and build on live. Then apply:
- **Theme:** `set_theme{accent:"E2463A", ink:"1A1A1A", muted:"57585B"}` once, so headings and
  Accent-1 table styles take LTM coral at a legible depth.
- **Cover block:** `assets/backgrounds/ltm-wave-doc-banner.jpg` full text width (8:3) →
  eyebrow (9pt bold caps, Coral Text) → title 28pt Arial regular, Ink → subtitle 14pt Slate →
  `assets/logos/ltm-logo-coral.png` about 1.2in wide. For A4 report covers use
  `ltm-wave-portrait-ink.jpg`.
- **Type:** Arial throughout. Body 10.5pt Ink at 1.15 spacing. H1 22-24pt regular, coral (theme).
  H2 14pt bold Ink. H3 11pt bold Coral Text. Captions and sources 8-9pt Slate `57585B`.
- **Tables:** `LightShading-Accent1` (rules and banding) or `MediumShading1-Accent1` (solid header
  band); numbers right-aligned; a source line under each table.
- **Header:** `LTM | <Document title>`. Footers are not applied on live, so keep page references
  in the header text.
- Optional sign-off for marketing documents only: "It's time to Outcreate."

### C. Excel workbook

Load the `xlsx` skill. Arial 10/11. Title row 18pt regular Ink, subtitle 10pt Slate. Header band
Ink `1A1A1A` with white bold text and a Coral bottom border (or Coral fill with **Ink** text).
Totals on Coral Wash `FEF2ED`; subtotals `EAEBEC`. Negative values in Coral Text `E2463A`.
Freeze the header row, use real number formats, and size the columns. Chart series in order:
Coral `FF5E4F`, Prior Grey `CCCBCA`, Ink `1A1A1A`, Steel `559BB5`, L&T Blue `004B88`. No 3D,
light or no gridlines, values labelled.

### D. HTML page, Loop page or email

CSS tokens and patterns are in `references/other-formats.md`. Embed the logo SVG inline from
`assets/logos/` and the wave as a base64 hero background. For Outlook emails use table layout,
inline CSS and `bgcolor` attributes. Use no image logo (a text "LTM" mark in Coral) and follow
the existing `ltm-renewals-email` conventions.

### E. Images, banners and artwork

- Fresh particle waves at any size:
  `python scripts/particle_wave.py --preset {cover|corner|corner-tl|band|portrait} --width W --height H --bg {ink|black|cloud|white|coral|transparent} --out working/<name>.jpg`.
  Use the bundled 16:9 originals first; generate for other aspect ratios.
- Card or tile art: `python scripts/make_card.py --w-emu <cx> --h-emu <cy> --style {frost|solid} --fill <hex> --out working/<name>.png`.
- Photography and icon prompt guidance: `references/other-formats.md`.

## Brand QA checklist

1. **Logo:** an official file, the right variant for the ground, cover and closer only, clear space at least ½ the logo height, never under 0.5in wide.
2. **Colour:** palette hexes only (`brand_check.py` flags others); Coral is one accent, not a background, except the coral so-what bar and stat tile.
3. **Type:** Arial in Office (Klarheit in design tools); headlines regular weight, sentence case; at least 12pt on slides.
4. **Contrast:** coral words on light grounds use `E2463A`; text on coral is Ink unless 18pt+; text on photos sits on a 45% Ink scrim.
5. **Layout:** eyebrow and title at one x/y on every interior slide; content low; air above; page numbers on content slides.
6. **Voice:** the headline is the takeaway; one idea per slide; proof and source on claim slides; *Business Creativity* and *Outcreate* capitalised as brand terms.
7. **Facts:** every number traceable to a dated source (in notes or a source line).

## Guardrails

- Never fabricate figures, clients, awards, quotes or case studies. Use the user's data or the
  dated proof points in `references/voice-and-messaging.md`, and refresh them when newer
  official numbers exist. Otherwise leave visible `[Add …]` placeholders.
- Keep client names anonymous unless the user confirms they are public (LTM's own case studies
  say "one of North America's largest banks").
- Use the L&T symbol only inside the full "A Larsen & Toubro Group Company" lockup. Never use it
  as LTM's logo, and never use the old LTIMindtree logo or colours.
- Partner logos only from official files the user supplies. Otherwise set partner names as text
  (as the builder does).
- Generated people must look illustrative. Never present them as real LTM employees or clients.
- On a user's existing deck, change only what they asked for.

## Failure handling

- **Live batch refused:** fix the named ops and resend once as one batch; never resend verbatim.
- **HTTP 500 or "session expired":** re-read the model, resend only the missing ops once. If that
  fails, stop and tell the user the editing service is temporarily unavailable. Never loop.
- **Image not found (404):** rebuild into a new `--out` folder; wait about a minute after writing
  new files before applying.
- **Klarheit Grotesk unavailable** (always in Office): use Arial and say so if the user expects
  the licensed face.
- **No photo for an image layout:** generate one (section E) or leave the grey placeholder and say so.

## Files

- `assets/logos/`: `ltm-logo-{coral,ink,white}.{svg,png}` (ratio 3.8:1) and `lt-group-company-lockup-{white,ink}.{svg,png}` (ratio 5.26:1).
- `assets/backgrounds/`: `ltm-wave-cover-{ink,black}.jpg` (16:9 cover and closer), `ltm-wave-corner-cloud.png` and `ltm-wave-corner-ink{,-br}.png` (transparent corner accents), `ltm-wave-doc-banner.jpg` (8:3), `ltm-wave-portrait-ink.jpg` (A4), `ltm-banner-ink.jpg` (web banner).
- `scripts/`: `ltm_deck.py` (plan → live patch batches), `make_card.py`, `particle_wave.py`, `brand_check.py`.
- `references/`: `brand-guidelines.md`, `voice-and-messaging.md`, `slide-layouts.md`, `other-formats.md`, `sample-plan.json`, `layout-gallery.jpg`.

## Example

```
User: "Make an LTM deck pitching AI-led contact-centre modernisation to a retail bank."
→ facts: user's notes + the FY26 annual-report case study (anonymised bank, USD 12 → 0.7 per interaction)
→ storyline "client pitch" (references/slide-layouts.md) → working/plan.json
→ python scripts/ltm_deck.py --plan working/plan.json --out working/ltm-build-1   (fix fit warnings)
→ host-CreateArtifact(live) → apply manifest calls in order → render all slides → brand_check.py
→ fix → deliver "<Title>.pptx" with sources in the speaker notes
```
